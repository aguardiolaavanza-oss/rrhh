'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { geoMercator, geoPath } from 'd3-geo';
import { feature } from 'topojson-client';
import type { FeatureCollection, Geometry } from 'geojson';
import provincesTopo from 'es-atlas/es/provinces.json';

export interface MapStore {
  id: number;
  name: string;
  submissions: number;
  cash: number;
}

const W = 720;
const H = 520;
const CX = W / 2;
const CY = H / 2;
const MIN_K = 1;
const MAX_K = 14;

// Inset de Canarias (esquina inferior izquierda, como en los mapas oficiales)
const INSET = { x: 14, y: H - 132, w: 170, h: 118 };

const norm = (s: string) =>
  s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

// Mapa de España por provincias con zoom (rueda/botones/arrastre) y buscador.
// Cada tienda se sitúa en el centroide de su provincia (la provincia se
// deduce del nombre de la tienda); el marcador destaca la recaudación y al
// pulsarlo se filtra el dashboard por esa tienda.
export default function SpainMap({ stores }: { stores: MapStore[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();

  const { mainland, canary, markers } = useMemo(() => {
    const fc = feature(
      provincesTopo as any,
      (provincesTopo as any).objects.provinces
    ) as unknown as FeatureCollection<Geometry, { name: string }>;

    const isCanary = (n: string) => /las palmas|tenerife/i.test(n);
    const mainFeats = fc.features.filter((f) => !isCanary(f.properties.name));
    const canaryFeats = fc.features.filter((f) => isCanary(f.properties.name));

    const mainProj = geoMercator().fitExtent([[8, 8], [W - 8, H - 8]], { type: 'FeatureCollection', features: mainFeats } as any);
    const mainPath = geoPath(mainProj);
    const canProj = geoMercator().fitExtent(
      [[INSET.x + 6, INSET.y + 6], [INSET.x + INSET.w - 6, INSET.y + INSET.h - 6]],
      { type: 'FeatureCollection', features: canaryFeats } as any
    );
    const canPath = geoPath(canProj);

    const mainland = mainFeats.map((f) => ({ name: f.properties.name, d: mainPath(f) || '' , centroid: mainPath.centroid(f) as [number, number] }));
    const canary = canaryFeats.map((f) => ({ name: f.properties.name, d: canPath(f) || '', centroid: canPath.centroid(f) as [number, number] }));

    // Tienda → provincia: el nombre de la tienda aparece en el de la provincia
    // ("Alicante" casa con "Alacant/Alicante"). Sin provincia, sin marcador.
    const all = [...mainland.map((p) => ({ ...p, inset: false })), ...canary.map((p) => ({ ...p, inset: true }))];
    const markers = stores.flatMap((s) => {
      const prov = all.find((p) => norm(p.name).includes(norm(s.name)) || norm(s.name).includes(norm(p.name).split('/')[0]));
      return prov ? [{ ...s, province: prov.name, cx: prov.centroid[0], cy: prov.centroid[1], inset: prov.inset }] : [];
    });
    return { mainland, canary, markers };
  }, [stores]);

  const [t, setT] = useState({ k: 1, x: 0, y: 0 });
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<number | null>(params.get('tienda') ? Number(params.get('tienda')) : null);
  const svgRef = useRef<SVGSVGElement>(null);
  const drag = useRef<{ px: number; py: number; x: number; y: number } | null>(null);

  const clampT = (k: number, x: number, y: number) => ({ k, x, y });

  function zoomAt(px: number, py: number, factor: number) {
    setT((cur) => {
      const k = Math.min(MAX_K, Math.max(MIN_K, cur.k * factor));
      if (k === cur.k) return cur;
      return clampT(k, px - ((px - cur.x) * k) / cur.k, py - ((py - cur.y) * k) / cur.k);
    });
  }

  // Rueda del ratón: React registra wheel como pasivo, así que lo enganchamos
  // a mano para poder hacer preventDefault (evitar el scroll de la página).
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = svg.getBoundingClientRect();
      const px = ((e.clientX - r.left) / r.width) * W;
      const py = ((e.clientY - r.top) / r.height) * H;
      zoomAt(px, py, Math.exp(-e.deltaY * 0.0018));
    };
    svg.addEventListener('wheel', onWheel, { passive: false });
    return () => svg.removeEventListener('wheel', onWheel);
  }, []);

  function centerOn(cx: number, cy: number, k = 5) {
    setT(clampT(k, CX - k * cx, CY - k * cy));
  }

  function selectStore(m: (typeof markers)[number] | undefined, updateFilter: boolean) {
    if (!m) return;
    setSelected(m.id);
    if (!m.inset) centerOn(m.cx, m.cy, Math.max(t.k, 5));
    if (updateFilter) {
      const next = new URLSearchParams(params.toString());
      next.set('tienda', String(m.id));
      router.replace(`${pathname}?${next.toString()}`, { scroll: false });
    }
  }

  const matches = query.trim()
    ? markers.filter((m) => norm(m.name).includes(norm(query)) || norm(m.province).includes(norm(query)))
    : [];

  const maxCash = Math.max(1, ...markers.map((m) => m.cash));
  const eur = (n: number) => n.toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const storeProvinces = new Set(markers.map((m) => m.province));
  const sk = Math.sqrt(t.k);

  const renderMarker = (m: (typeof markers)[number], inset: boolean) => {
    const r = (7 + 9 * Math.sqrt(m.cash / maxCash)) / (inset ? 1 : sk);
    const top = m.cash === maxCash && m.cash > 0;
    return (
      <g
        key={m.id}
        transform={`translate(${m.cx},${m.cy})`}
        style={{ cursor: 'pointer' }}
        onClick={(e) => { e.stopPropagation(); selectStore(m, true); }}
      >
        <title>{`${m.name} · ${m.submissions} respuestas · ${eur(m.cash)}`}</title>
        {selected === m.id && <circle r={r + 5 / sk} fill="none" stroke="var(--navy)" strokeWidth={2} vectorEffect="non-scaling-stroke" strokeDasharray="4 3" />}
        <circle r={r} fill={top ? 'var(--orange)' : 'var(--blue)'} fillOpacity={0.85} stroke="#fff" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
        <text y={-r - 4 / sk} textAnchor="middle" fontSize={11.5 / (inset ? 1 : sk)} fontWeight={700} fill="var(--navy)" stroke="#fff" strokeWidth={3 / sk} paintOrder="stroke">
          {m.name}
        </text>
        <text y={-r - 4 / sk} dy={-11 / (inset ? 1 : sk)} textAnchor="middle" fontSize={10 / (inset ? 1 : sk)} fontWeight={600} fill="var(--ink-2)" stroke="#fff" strokeWidth={3 / sk} paintOrder="stroke">
          {eur(m.cash)}
        </text>
      </g>
    );
  };

  return (
    <div>
      <div className="row mb" style={{ position: 'relative' }}>
        <div className="searchbox" style={{ flex: 1, minWidth: 180 }}>
          <input
            type="search"
            placeholder="Buscar tienda en el mapa…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && matches[0]) { selectStore(matches[0], false); setQuery(''); } }}
          />
          {matches.length > 0 && (
            <div className="map-suggest">
              {matches.slice(0, 6).map((m) => (
                <button key={m.id} type="button" onClick={() => { selectStore(m, false); setQuery(''); }}>
                  📍 {m.name} <span className="muted">({m.province}) · {eur(m.cash)}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="row" style={{ flexWrap: 'nowrap', gap: 6 }}>
          <button type="button" className="btn ghost sm" onClick={() => zoomAt(CX, CY, 1.5)} title="Acercar">＋</button>
          <button type="button" className="btn ghost sm" onClick={() => zoomAt(CX, CY, 1 / 1.5)} title="Alejar">－</button>
          <button type="button" className="btn ghost sm" onClick={() => { setT({ k: 1, x: 0, y: 0 }); setSelected(null); }} title="Vista completa">⤢</button>
        </div>
      </div>

      <svg
        ref={svgRef}
        viewBox={`0 0 ${W} ${H}`}
        role="img"
        aria-label="Mapa de España con las tiendas"
        style={{ width: '100%', height: 'auto', background: '#fbfbfb', borderRadius: 10, border: '1px solid var(--line)', touchAction: 'none', display: 'block' }}
        onPointerDown={(e) => {
          const r = svgRef.current!.getBoundingClientRect();
          drag.current = { px: ((e.clientX - r.left) / r.width) * W, py: ((e.clientY - r.top) / r.height) * H, x: t.x, y: t.y };
          (e.target as Element).setPointerCapture?.(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!drag.current) return;
          const r = svgRef.current!.getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * W;
          const py = ((e.clientY - r.top) / r.height) * H;
          setT((cur) => ({ ...cur, x: drag.current!.x + (px - drag.current!.px), y: drag.current!.y + (py - drag.current!.py) }));
        }}
        onPointerUp={() => (drag.current = null)}
        onPointerLeave={() => (drag.current = null)}
      >
        <g transform={`translate(${t.x},${t.y}) scale(${t.k})`}>
          {mainland.map((p) => (
            <path
              key={p.name}
              d={p.d}
              fill={storeProvinces.has(p.name) ? 'var(--blue-soft)' : '#e9e9e9'}
              stroke="#fff"
              strokeWidth={1}
              vectorEffect="non-scaling-stroke"
            >
              <title>{p.name}</title>
            </path>
          ))}
          {markers.filter((m) => !m.inset).map((m) => renderMarker(m, false))}
        </g>

        {/* Inset Canarias (estático, no le afecta el zoom del peninsular) */}
        <g>
          <rect x={INSET.x} y={INSET.y} width={INSET.w} height={INSET.h} fill="#fff" stroke="var(--line)" rx={8} />
          {canary.map((p) => (
            <path key={p.name} d={p.d} fill={storeProvinces.has(p.name) ? 'var(--blue-soft)' : '#e9e9e9'} stroke="#fff" strokeWidth={1}>
              <title>{p.name}</title>
            </path>
          ))}
          {markers.filter((m) => m.inset).map((m) => renderMarker(m, true))}
          <text x={INSET.x + 8} y={INSET.y + 16} fontSize={10} fill="var(--ink-3)">Canarias</text>
        </g>
      </svg>

      <p className="muted" style={{ margin: '8px 2px 0' }}>
        <span className="badge warn plain" style={{ background: 'var(--orange)', color: '#fff' }}>●</span> mayor recaudación ·{' '}
        <span style={{ color: 'var(--blue)', fontWeight: 700 }}>●</span> resto de tiendas · rueda o botones para hacer zoom,
        arrastra para moverte, clic en una tienda para filtrar el dashboard.
      </p>
    </div>
  );
}
