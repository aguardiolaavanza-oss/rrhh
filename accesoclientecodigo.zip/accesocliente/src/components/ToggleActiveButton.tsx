'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function ToggleActiveButton({ id, active }: { id: number; active: boolean }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  return (
    <button
      className={active ? 'btn danger sm' : 'btn sm'}
      disabled={loading}
      onClick={async () => {
        if (active && !confirm('¿Desactivar este cuestionario? Dejará de aparecer a los comerciales, pero el histórico de respuestas se conserva.')) return;
        setLoading(true);
        await fetch(`/api/admin/questionnaires/${id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ active: !active }),
        });
        router.refresh();
        setLoading(false);
      }}
    >
      {active ? 'Desactivar' : 'Activar'}
    </button>
  );
}
