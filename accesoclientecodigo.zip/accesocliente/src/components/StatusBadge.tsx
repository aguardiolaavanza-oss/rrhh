import { PeriodStatus, STATUS_LABELS } from '@/lib/periods';

// Semáforo visual: verde (a tiempo / completado), ámbar (a punto de vencer /
// completado tarde), rojo (vencido). Siempre con etiqueta de texto, nunca solo color.
const KIND: Record<PeriodStatus, string> = {
  A_TIEMPO: 'ok',
  POR_VENCER: 'warn',
  VENCIDO: 'bad',
  COMPLETADO: 'ok',
  COMPLETADO_TARDE: 'warn',
};

export default function StatusBadge({ status }: { status: PeriodStatus }) {
  return <span className={`badge ${KIND[status]}`}>{STATUS_LABELS[status]}</span>;
}
