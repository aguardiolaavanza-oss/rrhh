'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';

// Filtros del listado de usuarios: rol, tienda, estado y búsqueda por nombre/email.
export default function UsersFilters({ stores }: { stores: { id: number; name: string }[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [buscar, setBuscar] = useState(params.get('buscar') || '');
  const debounce = useRef<ReturnType<typeof setTimeout>>();

  function setParam(key: string, value: string) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    router.replace(`${pathname}?${next.toString()}`, { scroll: false });
  }

  useEffect(() => {
    clearTimeout(debounce.current);
    debounce.current = setTimeout(() => {
      if ((params.get('buscar') || '') !== buscar) setParam('buscar', buscar);
    }, 250);
    return () => clearTimeout(debounce.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [buscar]);

  return (
    <div className="filters card" style={{ padding: '14px 16px' }}>
      <label className="f"><span>Buscar</span>
        <div className="searchbox">
          <input type="search" placeholder="Nombre o email" value={buscar} onChange={(e) => setBuscar(e.target.value)} />
        </div>
      </label>
      <label className="f"><span>Rol</span>
        <select value={params.get('rol') || ''} onChange={(e) => setParam('rol', e.target.value)}>
          <option value="">Todos</option>
          <option value="ADMIN">Admin</option>
          <option value="RRHH">RRHH</option>
          <option value="GESTOR">Gestor</option>
          <option value="COMERCIAL">Comercial</option>
        </select>
      </label>
      <label className="f"><span>Tienda</span>
        <select value={params.get('tienda') || ''} onChange={(e) => setParam('tienda', e.target.value)}>
          <option value="">Todas</option>
          {stores.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </label>
      <label className="f"><span>Estado</span>
        <select value={params.get('estado') || ''} onChange={(e) => setParam('estado', e.target.value)}>
          <option value="">Todos</option>
          <option value="INVITADO">Invitado</option>
          <option value="ACTIVO">Activo</option>
          <option value="DESACTIVADO">Desactivado</option>
        </select>
      </label>
      <button className="btn ghost sm" type="button" onClick={() => { setBuscar(''); router.replace(pathname, { scroll: false }); }}>
        Limpiar
      </button>
    </div>
  );
}
