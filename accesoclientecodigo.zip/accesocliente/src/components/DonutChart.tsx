// Donut de respuestas por tienda (SVG puro, estilo panel de referencia).
// Paleta categórica validada: azul, naranja, verde; a partir de la 4ª
// categoría se agrupa en "Otras" (gris). Etiquetas siempre visibles.
const COLORS = ['#356EB5', '#E57A28', '#209E73'];
const OTHER = '#8c8c8c';

export default function DonutChart({ data, centerLabel }: { data: { label: string; value: number }[]; centerLabel: string }) {
  const sorted = [...data].sort((a, b) => b.value - a.value);
  const head = sorted.slice(0, COLORS.length);
  const rest = sorted.slice(COLORS.length);
  const slices = [
    ...head.map((d, i) => ({ ...d, color: COLORS[i] })),
    ...(rest.length ? [{ label: 'Otras', value: rest.reduce((a, d) => a + d.value, 0), color: OTHER }] : []),
  ].filter((s) => s.value > 0);

  const total = slices.reduce((a, s) => a + s.value, 0);
  const R = 62;
  const STROKE = 26;
  const C = 2 * Math.PI * R;
  let acc = 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
      <svg viewBox="0 0 180 180" style={{ width: 180, maxWidth: '100%' }} role="img" aria-label={`Distribución: ${centerLabel}`}>
        <g transform="rotate(-90 90 90)">
          {slices.map((s) => {
            const frac = total ? s.value / total : 0;
            const el = (
              <circle
                key={s.label}
                cx="90" cy="90" r={R}
                fill="none"
                stroke={s.color}
                strokeWidth={STROKE}
                strokeDasharray={`${Math.max(frac * C - 2, 0)} ${C - Math.max(frac * C - 2, 0)}`}
                strokeDashoffset={-acc * C}
                strokeLinecap="butt"
              >
                <title>{`${s.label}: ${s.value} (${Math.round(frac * 100)}%)`}</title>
              </circle>
            );
            acc += frac;
            return el;
          })}
        </g>
        <text x="90" y="86" textAnchor="middle" fontSize="26" fontWeight="700" fill="var(--navy)">{total}</text>
        <text x="90" y="104" textAnchor="middle" fontSize="10.5" fill="var(--ink-2)">{centerLabel}</text>
      </svg>
      <div style={{ width: '100%' }}>
        {slices.map((s) => (
          <div key={s.label} className="row" style={{ padding: '3px 2px', fontSize: 13 }}>
            <span style={{ width: 10, height: 10, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
            <span style={{ fontWeight: 600, color: 'var(--ink)' }}>{s.label}</span>
            <span className="spacer" />
            <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--ink-2)' }}>
              {s.value} · {total ? Math.round((s.value / total) * 100) : 0}%
            </span>
          </div>
        ))}
        {slices.length === 0 && <p className="muted">Sin datos en el filtro actual.</p>}
      </div>
    </div>
  );
}
