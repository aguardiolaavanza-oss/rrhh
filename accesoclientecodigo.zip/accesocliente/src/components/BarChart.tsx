// Gráfico de barras SVG (serie única, azul de marca) con tooltip nativo por
// barra y etiquetas directas selectivas (solo el máximo). Sin dependencias.
export default function BarChart({
  data,
  height = 220,
}: {
  data: { label: string; value: number }[];
  height?: number;
}) {
  const width = 720;
  const pad = { top: 18, right: 8, bottom: 30, left: 34 };
  const iw = width - pad.left - pad.right;
  const ih = height - pad.top - pad.bottom;
  const max = Math.max(1, ...data.map((d) => d.value));
  const maxIdx = data.findIndex((d) => d.value === max);
  const n = data.length || 1;
  const gap = 2;
  const bw = Math.max(2, iw / n - gap);
  const ticks = [0, Math.ceil(max / 2), max];
  const labelEvery = Math.ceil(n / 10);

  return (
    <div className="chart">
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Evolución temporal de respuestas">
        {ticks.map((t) => {
          const y = pad.top + ih - (t / max) * ih;
          return (
            <g key={t}>
              <line x1={pad.left} x2={width - pad.right} y1={y} y2={y} stroke="var(--line)" strokeWidth="1" />
              <text x={pad.left - 6} y={y + 4} textAnchor="end" fontSize="10" fill="var(--ink-3)">{t}</text>
            </g>
          );
        })}
        {data.map((d, i) => {
          const h = (d.value / max) * ih;
          const x = pad.left + i * (iw / n) + gap / 2;
          const y = pad.top + ih - h;
          return (
            <g key={i}>
              <rect className="bar" x={x} y={y} width={bw} height={Math.max(h, d.value > 0 ? 2 : 0)} rx="3">
                <title>{`${d.label}: ${d.value}`}</title>
              </rect>
              {i === maxIdx && d.value > 0 && (
                <text x={x + bw / 2} y={y - 5} textAnchor="middle" fontSize="10.5" fontWeight="700" fill="var(--navy)">
                  {d.value}
                </text>
              )}
              {i % labelEvery === 0 && (
                <text x={x + bw / 2} y={height - 10} textAnchor="middle" fontSize="9.5" fill="var(--ink-3)">
                  {d.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
