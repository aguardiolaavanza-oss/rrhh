'use client';

export default function LogoutButton({ className = 'btn ghost sm' }: { className?: string }) {
  return (
    <button
      className={className}
      onClick={async () => {
        await fetch('/api/auth/logout', { method: 'POST' });
        window.location.href = '/login';
      }}
    >
      Salir
    </button>
  );
}
