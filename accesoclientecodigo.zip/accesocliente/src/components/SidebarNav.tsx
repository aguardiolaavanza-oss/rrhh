'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LINKS: { href: string; label: string; icon: string; exact?: boolean }[] = [
  { href: '/admin', label: 'Dashboard', icon: '📊', exact: true },
  { href: '/admin/ranking', label: 'Ranking recaudación', icon: '💶' },
  { href: '/admin/cuestionarios', label: 'Cuestionarios', icon: '📝' },
  { href: '/admin/historial', label: 'Histórico / Auditoría', icon: '🗂️' },
];

const ADMIN_LINKS: typeof LINKS = [{ href: '/admin/usuarios', label: 'Gestión de accesos', icon: '👥' }];

export default function SidebarNav({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const links = isAdmin ? [...LINKS, ...ADMIN_LINKS] : LINKS;
  return (
    <nav>
      {links.map((l) => {
        const active = l.exact ? pathname === l.href : pathname.startsWith(l.href);
        return (
          <Link key={l.href} href={l.href} className={active ? 'active' : ''}>
            <span>{l.icon}</span>{l.label}
          </Link>
        );
      })}
    </nav>
  );
}
