'use client';

import { useState } from 'react';

interface RowResult {
  row: number;
  name: string;
  email: string;
  ok: boolean;
  error?: string;
  inviteLink?: string;
}

interface ImportResponse {
  imported: number;
  failed: number;
  results: RowResult[];
}

// Subida del Excel y resumen fila a fila: qué se importó y qué falló y por qué.
export default function ImportUsers() {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ImportResponse | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError('');
    setResult(null);
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const res = await fetch('/api/admin/users/import', { method: 'POST', body: form });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error || 'Error al importar.');
    setResult(data);
  }

  return (
    <>
      <form className="card mb" onSubmit={onSubmit}>
        {error && <div className="msg err">{error}</div>}
        <label className="f"><span>Archivo Excel (.xlsx)</span>
          <input type="file" name="file" accept=".xlsx" required />
        </label>
        <button className="btn orange" disabled={loading}>{loading ? 'Importando…' : 'Importar usuarios'}</button>
      </form>

      {result && (
        <div className="card">
          <div className="row mb">
            <span className="badge ok">✔ {result.imported} importados</span>
            <span className={`badge ${result.failed ? 'bad' : 'muted'}`}>✖ {result.failed} con errores</span>
          </div>
          <div className="tablewrap">
            <table className="data">
              <thead><tr><th>Fila</th><th>Nombre</th><th>Email</th><th>Resultado</th></tr></thead>
              <tbody>
                {result.results.map((r) => (
                  <tr key={r.row}>
                    <td>{r.row}</td>
                    <td>{r.name || '—'}</td>
                    <td>{r.email || '—'}</td>
                    <td>
                      {r.ok ? (
                        <>
                          <span className="badge ok">Importado · invitación {r.inviteLink ? 'generada' : 'enviada'}</span>
                          {r.inviteLink && (
                            <div className="muted" style={{ marginTop: 4, wordBreak: 'break-all' }}>
                              Enlace (sin SMTP): <code className="k">{r.inviteLink}</code>
                            </div>
                          )}
                        </>
                      ) : (
                        <span className="badge bad">{r.error}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
}
