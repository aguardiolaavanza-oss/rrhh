'use client';

import { useState } from 'react';

// Formulario compartido: aceptar invitación y restablecer contraseña
export default function SetPasswordForm({ token, cta }: { token: string; cta: string }) {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError('');
    const form = new FormData(e.currentTarget);
    const password = String(form.get('password'));
    if (password.length < 8) return setError('La contraseña debe tener al menos 8 caracteres.');
    if (password !== form.get('password2')) return setError('Las contraseñas no coinciden.');
    setLoading(true);
    const res = await fetch('/api/auth/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, password }),
    });
    const data = await res.json();
    if (res.ok) window.location.href = data.redirect;
    else { setError(data.error || 'Error.'); setLoading(false); }
  }

  return (
    <form onSubmit={onSubmit}>
      {error && <div className="msg err">{error}</div>}
      <label className="f"><span>Nueva contraseña (mínimo 8 caracteres)</span>
        <input name="password" type="password" required minLength={8} autoComplete="new-password" />
      </label>
      <label className="f"><span>Repite la contraseña</span>
        <input name="password2" type="password" required minLength={8} autoComplete="new-password" />
      </label>
      <button className="btn orange" style={{ width: '100%', justifyContent: 'center' }} disabled={loading}>
        {loading ? 'Guardando…' : cta}
      </button>
    </form>
  );
}
