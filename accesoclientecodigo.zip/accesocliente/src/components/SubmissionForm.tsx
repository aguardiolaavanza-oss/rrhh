'use client';

import { useState } from 'react';

export interface FieldDef {
  id: number;
  label: string;
  type: 'TEXTO' | 'NUMERO' | 'SELECCION' | 'FECHA' | 'CHECKBOX' | 'FOTO';
  options: string[];
  required: boolean;
}

// Formulario de envío de cuestionario (empleado). Soporta texto, número,
// selección, fecha, checkbox y foto (multipart).
export default function SubmissionForm({ questionnaireId, fields }: { questionnaireId: number; fields: FieldDef[] }) {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const form = new FormData(e.currentTarget);
    form.set('questionnaireId', String(questionnaireId));
    const res = await fetch('/api/submissions', { method: 'POST', body: form });
    const data = await res.json();
    if (res.ok) window.location.href = `/empleado/historial/${data.id}?enviado=1`;
    else { setError(data.error || 'Error al enviar.'); setLoading(false); }
  }

  return (
    <form onSubmit={onSubmit} className="card" style={{ padding: '20px 18px' }}>
      {error && <div className="msg err">{error}</div>}
      {fields.map((f) => {
        const name = `field_${f.id}`;
        switch (f.type) {
          case 'CHECKBOX':
            return (
              <label className="check" key={f.id}>
                <input type="checkbox" name={name} value="true" /> {f.label}
              </label>
            );
          case 'SELECCION':
            return (
              <label className="f" key={f.id}><span>{f.label}{f.required && ' *'}</span>
                <select name={name} required={f.required} defaultValue="">
                  <option value="" disabled>Selecciona…</option>
                  {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </label>
            );
          case 'NUMERO':
            return (
              <label className="f" key={f.id}><span>{f.label}{f.required && ' *'}</span>
                <input type="number" step="0.01" inputMode="decimal" name={name} required={f.required} />
              </label>
            );
          case 'FECHA':
            return (
              <label className="f" key={f.id}><span>{f.label}{f.required && ' *'}</span>
                <input type="date" name={name} required={f.required} />
              </label>
            );
          case 'FOTO':
            return (
              <label className="f" key={f.id}><span>{f.label}{f.required && ' *'} 📷</span>
                <input type="file" name={name} accept="image/*" capture="environment" required={f.required} />
              </label>
            );
          default:
            return (
              <label className="f" key={f.id}><span>{f.label}{f.required && ' *'}</span>
                <textarea name={name} required={f.required} />
              </label>
            );
        }
      })}
      <button className="btn orange" style={{ width: '100%', justifyContent: 'center', marginTop: 8 }} disabled={loading}>
        {loading ? 'Enviando…' : 'Enviar cuestionario'}
      </button>
      <p className="muted" style={{ textAlign: 'center', marginTop: 10 }}>
        Una vez enviado no se puede modificar.
      </p>
    </form>
  );
}
