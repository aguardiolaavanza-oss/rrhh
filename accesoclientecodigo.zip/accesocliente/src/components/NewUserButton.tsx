'use client';

import { useState } from 'react';
import UserForm from './UserForm';

export default function NewUserButton({ stores }: { stores: { id: number; name: string }[] }) {
  const [open, setOpen] = useState(false);
  if (!open) return <button className="btn orange" onClick={() => setOpen(true)}>+ Nuevo usuario</button>;
  return <UserForm stores={stores} onClose={() => setOpen(false)} />;
}
