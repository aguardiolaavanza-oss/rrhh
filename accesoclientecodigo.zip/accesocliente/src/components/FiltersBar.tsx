'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';

interface Option { id: number; name: string }

// Filtros combinables del panel: búsqueda de tienda (lupa), selector de
// tienda, gestor, tipo de cuestionario y rango de fechas. Actualiza la URL
// al instante (la página es server component y se re-renderiza filtrada);
// la exportación a Excel usa exactamente estos mismos parámetros.
export default function FiltersBar({
  stores,
  questionnaires,
  gestores,
  exportPath,
}: {
  stores: Option[];
  questionnaires: Option[];
  gestores?: Option[];
  exportPath?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [buscar, setBuscar] = useState(params.get('buscar') || '');
  const debounce = useRef<ReturnType<typeof setTimeout>>();

  function setParam(key: string, value: string) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    router.replace(`${pathname}?${next.toString()}`, { scroll: false });
  }

  // Búsqueda con pequeño debounce para que sea fluida al teclear
  useEffect(() => {
    clearTimeout(debounce.current);
    debounce.current = setTimeout(() => {
      if ((params.get('buscar') || '') !== buscar) setParam('buscar', buscar);
    }, 250);
    return () => clearTimeout(debounce.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [buscar]);

  const exportUrl = exportPath ? `${exportPath}?${params.toString()}` : null;

  return (
    <div className="filters card" style={{ padding: '14px 16px' }}>
      <label className="f"><span>Buscar tienda</span>
        <div className="searchbox">
          <input type="search" placeholder="Ej.: Murcia" value={buscar} onChange={(e) => setBuscar(e.target.value)} />
        </div>
      </label>
      <label className="f"><span>Tienda</span>
        <select value={params.get('tienda') || ''} onChange={(e) => setParam('tienda', e.target.value)}>
          <option value="">Todas</option>
          {stores.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </label>
      {gestores && (
        <label className="f"><span>Gestor</span>
          <select value={params.get('gestor') || ''} onChange={(e) => setParam('gestor', e.target.value)}>
            <option value="">Todos</option>
            {gestores.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </label>
      )}
      <label className="f"><span>Cuestionario</span>
        <select value={params.get('cuestionario') || ''} onChange={(e) => setParam('cuestionario', e.target.value)}>
          <option value="">Todos</option>
          {questionnaires.map((q) => <option key={q.id} value={q.id}>{q.name}</option>)}
        </select>
      </label>
      <label className="f"><span>Desde</span>
        <input type="date" value={params.get('desde') || ''} onChange={(e) => setParam('desde', e.target.value)} />
      </label>
      <label className="f"><span>Hasta</span>
        <input type="date" value={params.get('hasta') || ''} onChange={(e) => setParam('hasta', e.target.value)} />
      </label>
      <button className="btn ghost sm" type="button" onClick={() => { setBuscar(''); router.replace(pathname, { scroll: false }); }}>
        Limpiar
      </button>
      {exportUrl && (
        <a className="btn sm" href={exportUrl} download>⬇ Exportar a Excel</a>
      )}
    </div>
  );
}
