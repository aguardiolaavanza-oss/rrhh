'use client';

import { useState } from 'react';

interface StoreOpt { id: number; name: string }
export interface BuilderField {
  id?: number;
  label: string;
  type: string;
  optionsText: string; // opciones separadas por ; (solo SELECCION)
  required: boolean;
  isCashAmount: boolean;
  hasAnswers?: boolean;
}
export interface BuilderInitial {
  id: number;
  title: string;
  description: string;
  frequency: string;
  deadlineTime: string;
  storeIds: number[];
  fields: BuilderField[];
}

const TYPES = [
  ['TEXTO', 'Texto'],
  ['NUMERO', 'Número'],
  ['SELECCION', 'Selección'],
  ['FECHA', 'Fecha'],
  ['CHECKBOX', 'Casilla (sí/no)'],
  ['FOTO', 'Foto'],
];

// Form builder visual: RRHH/Gestor crean o editan cuestionarios sin tocar
// código. Al editar, los campos que ya tienen respuestas no se pueden borrar
// (se retiran/archivan) para no romper el histórico.
export default function QuestionnaireBuilder({ stores, initial }: { stores: StoreOpt[]; initial?: BuilderInitial }) {
  const [title, setTitle] = useState(initial?.title || '');
  const [description, setDescription] = useState(initial?.description || '');
  const [frequency, setFrequency] = useState(initial?.frequency || 'DIARIO');
  const [deadlineTime, setDeadlineTime] = useState(initial?.deadlineTime || '21:00');
  const [storeIds, setStoreIds] = useState<number[]>(initial?.storeIds || stores.map((s) => s.id));
  const [fields, setFields] = useState<BuilderField[]>(
    initial?.fields || [{ label: '', type: 'TEXTO', optionsText: '', required: false, isCashAmount: false }]
  );
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const setField = (i: number, patch: Partial<BuilderField>) =>
    setFields((fs) => fs.map((f, j) => (j === i ? { ...f, ...patch } : f)));
  const move = (i: number, dir: -1 | 1) =>
    setFields((fs) => {
      const j = i + dir;
      if (j < 0 || j >= fs.length) return fs;
      const copy = [...fs];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });

  async function save() {
    setError('');
    if (!title.trim()) return setError('Pon un título al cuestionario.');
    if (storeIds.length === 0) return setError('Selecciona al menos una tienda.');
    if (fields.length === 0 || fields.some((f) => !f.label.trim())) return setError('Todos los campos necesitan una etiqueta.');
    setLoading(true);
    const body = {
      title, description, frequency,
      deadlineTime: frequency === 'PUNTUAL' ? null : deadlineTime,
      storeIds,
      fields: fields.map((f, i) => ({
        id: f.id, label: f.label.trim(), type: f.type,
        options: f.type === 'SELECCION' ? f.optionsText.split(';').map((o) => o.trim()).filter(Boolean) : [],
        required: f.required, isCashAmount: f.type === 'NUMERO' && f.isCashAmount, order: i,
      })),
    };
    const res = await fetch(initial ? `/api/admin/questionnaires/${initial.id}` : '/api/admin/questionnaires', {
      method: initial ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (res.ok) window.location.href = '/admin/cuestionarios?guardado=1';
    else { setError(data.error || 'Error al guardar.'); setLoading(false); }
  }

  return (
    <div className="card">
      {error && <div className="msg err">{error}</div>}
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <label className="f" style={{ flex: 2, minWidth: 220 }}><span>Título *</span>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ej.: Conteo de caja diario" />
        </label>
        <label className="f" style={{ flex: 1, minWidth: 140 }}><span>Frecuencia</span>
          <select value={frequency} onChange={(e) => setFrequency(e.target.value)}>
            <option value="DIARIO">Diario</option>
            <option value="SEMANAL">Semanal</option>
            <option value="MENSUAL">Mensual</option>
            <option value="PUNTUAL">Puntual (sin plazo)</option>
          </select>
        </label>
        {frequency !== 'PUNTUAL' && (
          <label className="f" style={{ minWidth: 120 }}><span>Hora límite</span>
            <input type="time" value={deadlineTime} onChange={(e) => setDeadlineTime(e.target.value)} />
          </label>
        )}
      </div>
      <label className="f"><span>Descripción</span>
        <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Instrucciones breves para el personal" />
      </label>

      <div className="f"><span style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: 'var(--ink-2)', fontSize: 13 }}>Tiendas a las que aplica *</span>
        <div className="pill-list">
          {stores.map((s) => (
            <label className="check" key={s.id} style={{ marginBottom: 0 }}>
              <input
                type="checkbox"
                checked={storeIds.includes(s.id)}
                onChange={(e) =>
                  setStoreIds((ids) => (e.target.checked ? [...ids, s.id] : ids.filter((x) => x !== s.id)))
                }
              />
              {s.name}
            </label>
          ))}
        </div>
      </div>

      <h3 style={{ margin: '18px 0 10px' }}>Campos del cuestionario</h3>
      {fields.map((f, i) => (
        <div className="fieldrow" key={i}>
          <div className="frgrid">
            <label className="f" style={{ marginBottom: 0 }}><span>Etiqueta *</span>
              <input value={f.label} onChange={(e) => setField(i, { label: e.target.value })} placeholder="Ej.: Importe recaudado (€)" />
            </label>
            <label className="f" style={{ marginBottom: 0 }}><span>Tipo</span>
              <select value={f.type} onChange={(e) => setField(i, { type: e.target.value })} disabled={f.hasAnswers}>
                {TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
            <div className="row" style={{ flexWrap: 'nowrap' }}>
              <button type="button" className="btn ghost sm" onClick={() => move(i, -1)} title="Subir">↑</button>
              <button type="button" className="btn ghost sm" onClick={() => move(i, 1)} title="Bajar">↓</button>
              <button
                type="button" className="btn danger sm"
                onClick={() => setFields((fs) => fs.filter((_, j) => j !== i))}
                title={f.hasAnswers ? 'Tiene respuestas: se retirará sin borrar el histórico' : 'Eliminar campo'}
              >
                {f.hasAnswers ? 'Retirar' : 'Quitar'}
              </button>
            </div>
          </div>
          {f.type === 'SELECCION' && (
            <label className="f" style={{ marginTop: 10, marginBottom: 0 }}><span>Opciones (separadas por ;)</span>
              <input value={f.optionsText} onChange={(e) => setField(i, { optionsText: e.target.value })} placeholder="Excelente; Bueno; Mejorable" />
            </label>
          )}
          <div className="row" style={{ marginTop: 10 }}>
            <label className="check" style={{ marginBottom: 0 }}>
              <input type="checkbox" checked={f.required} onChange={(e) => setField(i, { required: e.target.checked })} /> Obligatorio
            </label>
            {f.type === 'NUMERO' && (
              <label className="check" style={{ marginBottom: 0 }} title="Este importe alimenta el ranking de recaudación">
                <input type="checkbox" checked={f.isCashAmount} onChange={(e) => setField(i, { isCashAmount: e.target.checked })} />
                💶 Importe de caja (ranking de recaudación)
              </label>
            )}
            {f.hasAnswers && <span className="badge muted plain">Con respuestas: tipo bloqueado</span>}
          </div>
        </div>
      ))}
      <button
        type="button" className="btn ghost"
        onClick={() => setFields((fs) => [...fs, { label: '', type: 'TEXTO', optionsText: '', required: false, isCashAmount: false }])}
      >
        + Añadir campo
      </button>

      <div className="row mt">
        <button className="btn orange" onClick={save} disabled={loading}>
          {loading ? 'Guardando…' : initial ? 'Guardar cambios' : 'Crear cuestionario'}
        </button>
        <a className="btn ghost" href="/admin/cuestionarios">Cancelar</a>
      </div>
    </div>
  );
}
