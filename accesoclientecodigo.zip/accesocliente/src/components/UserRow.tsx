'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import UserForm, { UserFormInitial } from './UserForm';

interface StoreOpt { id: number; name: string }
export interface UserRowData extends UserFormInitial {
  status: string;
  storeNames: string;
  lastInvite: string | null;
  isSelf: boolean;
}

const STATUS_BADGE: Record<string, [string, string]> = {
  INVITADO: ['info', 'Invitado'],
  ACTIVO: ['ok', 'Activo'],
  DESACTIVADO: ['muted', 'Desactivado'],
};

// Fila de usuario con acciones: editar rol/tiendas, reenviar invitación,
// revocar o reactivar acceso. Todas las acciones llaman a APIs solo-ADMIN.
export default function UserRow({ user, stores }: { user: UserRowData; stores: StoreOpt[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [inviteLink, setInviteLink] = useState('');
  const [badgeKind, badgeText] = STATUS_BADGE[user.status] || ['muted', user.status];

  async function resend() {
    setBusy(true);
    const res = await fetch(`/api/admin/users/${user.id}/invite`, { method: 'POST' });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return alert(data.error || 'Error al enviar la invitación.');
    if (data.inviteLink) setInviteLink(data.inviteLink);
    else alert('Invitación enviada por email.');
    router.refresh();
  }

  async function toggleStatus() {
    const revocar = user.status !== 'DESACTIVADO';
    if (revocar && !confirm(`¿Revocar el acceso de ${user.name}? No podrá entrar hasta que se reactive.`)) return;
    setBusy(true);
    const res = await fetch(`/api/admin/users/${user.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: revocar ? 'revocar' : 'reactivar' }),
    });
    setBusy(false);
    if (!res.ok) return alert((await res.json()).error || 'Error.');
    router.refresh();
  }

  return (
    <>
      <tr>
        <td style={{ fontWeight: 600, color: 'var(--navy)' }}>{user.name}{user.isSelf && <span className="badge info plain" style={{ marginLeft: 6 }}>tú</span>}</td>
        <td>{user.email}</td>
        <td>{user.role}</td>
        <td>{user.storeNames || '—'}</td>
        <td><span className={`badge ${badgeKind}`}>{badgeText}</span></td>
        <td className="muted">{user.lastInvite || '—'}</td>
        <td>
          <div className="row" style={{ flexWrap: 'nowrap' }}>
            <button className="btn ghost sm" onClick={() => setEditing((v) => !v)} disabled={busy}>Editar</button>
            {user.status !== 'DESACTIVADO' && (
              <button className="btn ghost sm" onClick={resend} disabled={busy}>
                {user.status === 'INVITADO' ? 'Reenviar invitación' : 'Enviar reset'}
              </button>
            )}
            {!user.isSelf && (
              <button className={user.status === 'DESACTIVADO' ? 'btn sm' : 'btn danger sm'} onClick={toggleStatus} disabled={busy}>
                {user.status === 'DESACTIVADO' ? 'Reactivar' : 'Revocar'}
              </button>
            )}
          </div>
        </td>
      </tr>
      {inviteLink && (
        <tr><td colSpan={7}>
          <div className="msg info" style={{ marginBottom: 0 }}>
            Enlace de invitación (sin SMTP configurado): <code className="k" style={{ wordBreak: 'break-all' }}>{inviteLink}</code>{' '}
            <button className="btn sm" onClick={() => navigator.clipboard.writeText(inviteLink)}>Copiar</button>{' '}
            <button className="btn ghost sm" onClick={() => setInviteLink('')}>Ocultar</button>
          </div>
        </td></tr>
      )}
      {editing && (
        <tr><td colSpan={7}>
          <UserForm stores={stores} initial={user} onClose={() => setEditing(false)} />
        </td></tr>
      )}
    </>
  );
}
