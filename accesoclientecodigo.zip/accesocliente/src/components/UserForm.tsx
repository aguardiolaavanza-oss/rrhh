'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

interface StoreOpt { id: number; name: string }
export interface UserFormInitial {
  id: number;
  name: string;
  email: string;
  role: string;
  storeIds: number[];
}

// Alta individual / edición de usuario (solo administradora).
// COMERCIAL → una única tienda (radio). GESTOR → varias (checkboxes).
export default function UserForm({
  stores,
  initial,
  onClose,
}: {
  stores: StoreOpt[];
  initial?: UserFormInitial;
  onClose: () => void;
}) {
  const router = useRouter();
  const [name, setName] = useState(initial?.name || '');
  const [email, setEmail] = useState(initial?.email || '');
  const [role, setRole] = useState(initial?.role || 'COMERCIAL');
  const [storeIds, setStoreIds] = useState<number[]>(initial?.storeIds || []);
  const [error, setError] = useState('');
  const [inviteLink, setInviteLink] = useState('');
  const [loading, setLoading] = useState(false);

  const needsStores = role === 'GESTOR' || role === 'COMERCIAL';

  async function save() {
    setError('');
    setLoading(true);
    const res = await fetch(initial ? `/api/admin/users/${initial.id}` : '/api/admin/users', {
      method: initial ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, role, storeIds }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error || 'Error.');
    if (data.inviteLink) {
      // Sin SMTP configurado: mostramos el enlace para copiarlo a mano
      setInviteLink(data.inviteLink);
      router.refresh();
      return;
    }
    router.refresh();
    onClose();
  }

  if (inviteLink) {
    return (
      <div className="card mb" style={{ borderColor: 'var(--blue)' }}>
        <h3>Usuario creado ✔</h3>
        <p className="msg info">
          No hay servidor de email configurado (modo desarrollo). Copia y envía este enlace de invitación a {email}:
          <br /><code className="k" style={{ wordBreak: 'break-all' }}>{inviteLink}</code>
        </p>
        <div className="row">
          <button className="btn sm" onClick={() => navigator.clipboard.writeText(inviteLink)}>Copiar enlace</button>
          <button className="btn ghost sm" onClick={onClose}>Cerrar</button>
        </div>
      </div>
    );
  }

  return (
    <div className="card mb" style={{ borderColor: 'var(--blue)' }}>
      <h3>{initial ? `Editar: ${initial.name}` : 'Nuevo usuario'}</h3>
      {error && <div className="msg err">{error}</div>}
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <label className="f" style={{ flex: 1, minWidth: 180 }}><span>Nombre *</span>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre y apellidos" />
        </label>
        <label className="f" style={{ flex: 1, minWidth: 200 }}><span>Email *</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="persona@avanzafibra.com" />
        </label>
        <label className="f" style={{ minWidth: 140 }}><span>Rol *</span>
          <select value={role} onChange={(e) => { setRole(e.target.value); setStoreIds([]); }}>
            <option value="COMERCIAL">Comercial</option>
            <option value="GESTOR">Gestor</option>
            <option value="RRHH">RRHH</option>
            <option value="ADMIN">Admin</option>
          </select>
        </label>
      </div>
      {needsStores && (
        <div className="f">
          <span style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: 'var(--ink-2)', fontSize: 13 }}>
            {role === 'COMERCIAL' ? 'Tienda (una única) *' : 'Tiendas asignadas (una o varias) *'}
          </span>
          <div className="pill-list">
            {stores.map((s) => (
              <label className="check" key={s.id} style={{ marginBottom: 0 }}>
                <input
                  type={role === 'COMERCIAL' ? 'radio' : 'checkbox'}
                  name="store"
                  checked={storeIds.includes(s.id)}
                  onChange={(e) => {
                    if (role === 'COMERCIAL') setStoreIds([s.id]);
                    else setStoreIds((ids) => (e.target.checked ? [...ids, s.id] : ids.filter((x) => x !== s.id)));
                  }}
                />
                {s.name}
              </label>
            ))}
          </div>
        </div>
      )}
      <div className="row">
        <button className="btn orange" onClick={save} disabled={loading}>
          {loading ? 'Guardando…' : initial ? 'Guardar cambios' : 'Crear y enviar invitación'}
        </button>
        <button className="btn ghost" onClick={onClose}>Cancelar</button>
      </div>
    </div>
  );
}
