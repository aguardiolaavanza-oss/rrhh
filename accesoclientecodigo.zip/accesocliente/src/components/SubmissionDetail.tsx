// Detalle de un envío (solo lectura). Reutilizado por el historial del
// empleado y por la auditoría del panel de administración.
import type { Answer, Field, Submission, Questionnaire, Store, User } from '@prisma/client';

type Full = Submission & {
  questionnaire: Questionnaire;
  store: Store;
  user: User;
  answers: (Answer & { field: Field })[];
};

function renderValue(a: Answer & { field: Field }) {
  if (a.filePath) {
    return (
      <a href={`/api/files/${a.filePath}`} target="_blank" rel="noreferrer">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={`/api/files/${a.filePath}`} alt={a.labelSnapshot} style={{ maxWidth: 220, maxHeight: 160, borderRadius: 8, border: '1px solid var(--line)' }} />
      </a>
    );
  }
  if (a.field.type === 'CHECKBOX') return a.value === 'true' ? '✅ Sí' : '— No';
  if (a.field.type === 'NUMERO' && a.field.isCashAmount && a.value) {
    return <strong>{Number(a.value).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}</strong>;
  }
  return a.value || <span className="muted">—</span>;
}

export default function SubmissionDetail({ submission }: { submission: Full }) {
  return (
    <div className="card">
      <h2>{submission.questionnaire.title}</h2>
      <p className="muted" style={{ marginTop: 2 }}>
        Tienda {submission.store.name} · {submission.user.name} ·{' '}
        {submission.submittedAt.toLocaleString('es-ES', { dateStyle: 'full', timeStyle: 'short' })} · Periodo{' '}
        <code className="k">{submission.periodKey}</code>{' '}
        {submission.late
          ? <span className="badge warn">Enviado fuera de plazo</span>
          : <span className="badge ok">En plazo</span>}
      </p>
      <div className="tablewrap mt">
        <table className="data">
          <tbody>
            {submission.answers.map((a) => (
              <tr key={a.id}>
                <td style={{ width: '40%', fontWeight: 600, color: 'var(--navy)' }}>
                  {a.labelSnapshot}
                  {a.field.archived && <span className="badge muted plain" style={{ marginLeft: 6 }}>campo retirado</span>}
                </td>
                <td>{renderValue(a)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
