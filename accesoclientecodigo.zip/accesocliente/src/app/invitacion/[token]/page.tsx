import { db } from '@/lib/db';
import SetPasswordForm from '@/components/SetPasswordForm';

export const dynamic = 'force-dynamic';

export default async function InvitationPage({ params }: { params: { token: string } }) {
  const authToken = await db.authToken.findUnique({
    where: { token: params.token },
    include: { user: { include: { stores: { include: { store: true } } } } },
  });
  const valid = authToken && authToken.type === 'INVITE' && !authToken.usedAt && authToken.expiresAt > new Date();

  return (
    <div className="authwrap">
      <div className="authcard">
        <div className="logo">
          <strong>avanza <em>fibra</em></strong>
          <span>Activación de cuenta</span>
        </div>
        {!valid ? (
          <div className="msg err">
            Este enlace de invitación no es válido o ha caducado. Pide a administración que te reenvíe la invitación.
          </div>
        ) : (
          <>
            <p style={{ fontSize: 14, color: 'var(--ink-2)' }}>
              Hola, <strong>{authToken.user.name}</strong> ({authToken.user.email}).<br />
              Rol: <strong>{authToken.user.role}</strong>
              {authToken.user.stores.length > 0 && (
                <> · Tienda(s): <strong>{authToken.user.stores.map((s) => s.store.name).join(', ')}</strong></>
              )}
            </p>
            <p style={{ fontSize: 14, color: 'var(--ink-2)' }}>Crea tu contraseña para activar la cuenta:</p>
            <SetPasswordForm token={params.token} cta="Activar mi cuenta" />
          </>
        )}
      </div>
    </div>
  );
}
