import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { validateUserPayload } from '../validate';

// Editar usuario: nombre, rol y tienda(s). SOLO la administradora.
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'Solo la administradora puede gestionar accesos.' }, { status: 403 });

  const id = Number(params.id);
  const user = await db.user.findUnique({ where: { id } });
  if (!user) return NextResponse.json({ error: 'Usuario no encontrado.' }, { status: 404 });

  const body = await req.json();
  const parsed = await validateUserPayload({ ...body, email: body.email ?? user.email }, { excludeUserId: id });
  if ('error' in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });

  await db.$transaction([
    db.user.update({
      where: { id },
      data: { name: parsed.name, email: parsed.email, role: parsed.role },
    }),
    db.userStore.deleteMany({ where: { userId: id } }),
    db.userStore.createMany({ data: parsed.storeIds.map((storeId) => ({ userId: id, storeId })) }),
  ]);
  return NextResponse.json({ ok: true });
}

// Revocar o reactivar acceso. Revocar invalida la sesión al instante
// (getSession comprueba el estado en BD en cada petición).
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'Solo la administradora puede gestionar accesos.' }, { status: 403 });

  const id = Number(params.id);
  if (id === session.id) return NextResponse.json({ error: 'No puedes desactivar tu propia cuenta.' }, { status: 400 });
  const user = await db.user.findUnique({ where: { id } });
  if (!user) return NextResponse.json({ error: 'Usuario no encontrado.' }, { status: 404 });

  const { action } = await req.json();
  if (action === 'revocar') {
    await db.user.update({ where: { id }, data: { status: 'DESACTIVADO' } });
    await db.authToken.deleteMany({ where: { userId: id } }); // invalida invitaciones/resets pendientes
  } else if (action === 'reactivar') {
    await db.user.update({ where: { id }, data: { status: user.passwordHash ? 'ACTIVO' : 'INVITADO' } });
  } else {
    return NextResponse.json({ error: 'Acción no válida.' }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
