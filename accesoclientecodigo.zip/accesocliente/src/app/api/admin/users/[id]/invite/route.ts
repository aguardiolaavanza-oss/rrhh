import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { inviteUser } from '@/lib/invitations';

// Enviar / reenviar invitación a un usuario. SOLO la administradora.
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'Solo la administradora puede gestionar accesos.' }, { status: 403 });

  const user = await db.user.findUnique({ where: { id: Number(params.id) } });
  if (!user) return NextResponse.json({ error: 'Usuario no encontrado.' }, { status: 404 });
  if (user.status === 'DESACTIVADO') {
    return NextResponse.json({ error: 'La cuenta está desactivada: reactívala antes de invitar.' }, { status: 400 });
  }

  const mail = await inviteUser(user.id, session.id);
  return NextResponse.json({ ok: true, emailSent: mail.sent, inviteLink: mail.sent ? undefined : mail.link });
}
