import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { inviteUser } from '@/lib/invitations';
import { validateUserPayload } from './validate';

// Alta individual de usuario + envío de invitación. SOLO la administradora.
export async function POST(req: NextRequest) {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'Solo la administradora puede gestionar accesos.' }, { status: 403 });

  const body = await req.json();
  const parsed = await validateUserPayload(body, { requireEmailFree: true });
  if ('error' in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });

  const user = await db.user.create({
    data: {
      name: parsed.name,
      email: parsed.email,
      role: parsed.role,
      status: 'INVITADO',
      stores: { create: parsed.storeIds.map((storeId) => ({ storeId })) },
    },
  });

  const mail = await inviteUser(user.id, session.id);
  return NextResponse.json({
    ok: true,
    id: user.id,
    emailSent: mail.sent,
    inviteLink: mail.sent ? undefined : mail.link, // modo desarrollo: enlace visible en el panel
  });
}
