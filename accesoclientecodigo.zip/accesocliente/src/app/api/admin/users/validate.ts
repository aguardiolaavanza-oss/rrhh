import { db } from '@/lib/db';

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export interface UserPayload {
  name: string;
  email: string;
  role: string;
  storeIds: number[];
}

// Reglas de negocio de alta/edición de usuarios:
//  - COMERCIAL: exactamente UNA tienda (la suya)
//  - GESTOR: al menos una tienda (puede llevar varias)
//  - ADMIN / RRHH: sin tiendas (ven todas por rol)
export async function validateUserPayload(body: any, opts: { requireEmailFree?: boolean; excludeUserId?: number } = {}):
  Promise<UserPayload | { error: string }> {
  const name = String(body?.name || '').trim();
  const email = String(body?.email || '').trim().toLowerCase();
  const role = String(body?.role || '');
  let storeIds: number[] = Array.isArray(body?.storeIds)
    ? [...new Set(body.storeIds.map(Number).filter((n: number) => Number.isInteger(n)))] as number[]
    : [];

  if (!name) return { error: 'El nombre es obligatorio.' };
  if (!EMAIL_RE.test(email)) return { error: 'El email no es válido.' };
  if (!['ADMIN', 'RRHH', 'GESTOR', 'COMERCIAL'].includes(role)) return { error: 'Rol no válido (ADMIN, RRHH, GESTOR o COMERCIAL).' };

  if (role === 'COMERCIAL' && storeIds.length !== 1) return { error: 'Un Comercial debe tener exactamente una tienda.' };
  if (role === 'GESTOR' && storeIds.length === 0) return { error: 'Un Gestor necesita al menos una tienda asignada.' };
  if (role === 'ADMIN' || role === 'RRHH') storeIds = [];

  if (storeIds.length) {
    const found = await db.store.count({ where: { id: { in: storeIds } } });
    if (found !== storeIds.length) return { error: 'Alguna tienda seleccionada no existe.' };
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (existing && (opts.requireEmailFree || existing.id !== opts.excludeUserId)) {
    return { error: `Ya existe un usuario con el email ${email}.` };
  }

  return { name, email, role, storeIds };
}
