import ExcelJS from 'exceljs';
import { NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';

// Plantilla Excel descargable para la importación masiva de usuarios.
export async function GET() {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 });

  const stores = await db.store.findMany({ where: { active: true }, orderBy: { name: 'asc' } });

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Usuarios');
  ws.columns = [
    { header: 'nombre', key: 'nombre', width: 28 },
    { header: 'email', key: 'email', width: 32 },
    { header: 'rol', key: 'rol', width: 14 },
    { header: 'tienda', key: 'tienda', width: 24 },
  ];
  ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF17304F' } };

  ws.addRow({ nombre: 'María Ejemplo', email: 'maria@avanzafibra.com', rol: 'COMERCIAL', tienda: stores[0]?.name || 'Murcia' });
  ws.addRow({ nombre: 'Luis Ejemplo', email: 'luis@avanzafibra.com', rol: 'GESTOR', tienda: stores.map((s) => s.name).join('; ') });
  ws.addRow({ nombre: 'Ana Ejemplo', email: 'ana@avanzafibra.com', rol: 'RRHH', tienda: '' });

  const help = wb.addWorksheet('Instrucciones');
  help.getColumn(1).width = 90;
  [
    'Instrucciones de importación masiva:',
    '• Columnas obligatorias: nombre, email, rol, tienda (en la hoja "Usuarios").',
    '• rol: ADMIN, RRHH, GESTOR o COMERCIAL.',
    '• tienda: nombre exacto de la tienda. Para GESTOR puedes poner varias separadas por ";".',
    '• COMERCIAL: exactamente una tienda. RRHH/ADMIN: dejar vacío.',
    `• Tiendas disponibles ahora mismo: ${stores.map((s) => s.name).join(', ')}.`,
    '• Cada fila se valida por separado: las válidas se importan y reciben invitación; las erróneas se listan con su motivo.',
    '• Borra las filas de ejemplo antes de importar.',
  ].forEach((t) => help.addRow([t]));

  const buffer = await wb.xlsx.writeBuffer();
  return new NextResponse(Buffer.from(buffer), {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="plantilla_usuarios_avanza.xlsx"',
    },
  });
}
