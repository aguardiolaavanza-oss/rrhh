import ExcelJS from 'exceljs';
import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { inviteUser } from '@/lib/invitations';
import { EMAIL_RE } from '../validate';

interface RowResult {
  row: number;
  name: string;
  email: string;
  ok: boolean;
  error?: string;
  inviteLink?: string; // modo desarrollo (sin SMTP)
}

// Importación masiva desde Excel. Cada fila se valida DE FORMA INDEPENDIENTE:
// las válidas crean cuenta + invitación; las erróneas se reportan con el
// número de fila y el motivo exacto, sin abortar el resto.
export async function POST(req: NextRequest) {
  const session = await apiSession('ADMIN');
  if (!session) return NextResponse.json({ error: 'Solo la administradora puede gestionar accesos.' }, { status: 403 });

  const form = await req.formData();
  const file = form.get('file');
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: 'Sube un archivo .xlsx.' }, { status: 400 });
  }

  const wb = new ExcelJS.Workbook();
  try {
    await wb.xlsx.load(await file.arrayBuffer());
  } catch {
    return NextResponse.json({ error: 'No se pudo leer el archivo. ¿Es un .xlsx válido?' }, { status: 400 });
  }
  const ws = wb.getWorksheet('Usuarios') || wb.worksheets[0];
  if (!ws) return NextResponse.json({ error: 'El archivo no tiene hojas.' }, { status: 400 });

  // Mapeo de cabeceras (tolerante a mayúsculas/espacios)
  const header: Record<string, number> = {};
  ws.getRow(1).eachCell((cell, col) => {
    header[String(cell.value ?? '').trim().toLowerCase()] = col;
  });
  for (const required of ['nombre', 'email', 'rol', 'tienda']) {
    if (!header[required]) {
      return NextResponse.json(
        { error: `Falta la columna "${required}". Descarga la plantilla para ver el formato.` },
        { status: 400 }
      );
    }
  }

  const stores = await db.store.findMany();
  const storeByName = new Map(stores.map((s) => [s.name.trim().toLowerCase(), s]));
  const results: RowResult[] = [];
  const seenEmails = new Set<string>();

  const cellText = (row: ExcelJS.Row, col: number) => {
    const v = row.getCell(col).value;
    if (v && typeof v === 'object' && 'text' in v) return String((v as { text: unknown }).text).trim();
    return String(v ?? '').trim();
  };

  for (let r = 2; r <= ws.rowCount; r++) {
    const row = ws.getRow(r);
    const name = cellText(row, header['nombre']);
    const email = cellText(row, header['email']).toLowerCase();
    const role = cellText(row, header['rol']).toUpperCase();
    const tiendaRaw = cellText(row, header['tienda']);
    if (!name && !email && !role && !tiendaRaw) continue; // fila vacía

    const fail = (error: string) => results.push({ row: r, name, email, ok: false, error });

    if (!name) { fail('Falta el nombre.'); continue; }
    if (!EMAIL_RE.test(email)) { fail('Email vacío o no válido.'); continue; }
    if (!['ADMIN', 'RRHH', 'GESTOR', 'COMERCIAL'].includes(role)) { fail(`Rol "${role || '—'}" no válido (ADMIN, RRHH, GESTOR o COMERCIAL).`); continue; }
    if (seenEmails.has(email)) { fail('Email repetido dentro del archivo.'); continue; }

    let storeIds: number[] = [];
    if (role === 'GESTOR' || role === 'COMERCIAL') {
      const names = tiendaRaw.split(';').map((t) => t.trim()).filter(Boolean);
      if (names.length === 0) { fail(`Un ${role} necesita tienda(s).`); continue; }
      if (role === 'COMERCIAL' && names.length > 1) { fail('Un COMERCIAL solo puede tener una tienda.'); continue; }
      const missing = names.filter((n) => !storeByName.has(n.toLowerCase()));
      if (missing.length) { fail(`Tienda(s) no encontrada(s): ${missing.join(', ')}.`); continue; }
      storeIds = names.map((n) => storeByName.get(n.toLowerCase())!.id);
    }

    const existing = await db.user.findUnique({ where: { email } });
    if (existing) { fail('Ya existe un usuario con este email.'); continue; }

    try {
      const user = await db.user.create({
        data: {
          name, email, role, status: 'INVITADO',
          stores: { create: storeIds.map((storeId) => ({ storeId })) },
        },
      });
      const mail = await inviteUser(user.id, session.id);
      seenEmails.add(email);
      results.push({ row: r, name, email, ok: true, inviteLink: mail.sent ? undefined : mail.link });
    } catch (e) {
      fail('Error inesperado al crear la cuenta.');
    }
  }

  return NextResponse.json({
    ok: true,
    imported: results.filter((r) => r.ok).length,
    failed: results.filter((r) => !r.ok).length,
    results,
  });
}
