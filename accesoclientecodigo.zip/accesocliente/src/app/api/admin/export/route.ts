import ExcelJS from 'exceljs';
import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { resolveFilters } from '@/lib/adminFilters';

// Exportación a Excel (.xlsx). Recibe LOS MISMOS parámetros de filtro que el
// dashboard y el histórico (misma función resolveFilters), por lo que el
// archivo refleja exactamente los datos filtrados en pantalla. Sin filtros,
// exporta el histórico completo del ámbito del usuario.
export async function GET(req: NextRequest) {
  const session = await apiSession('ADMIN', 'RRHH', 'GESTOR');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 });

  const sp = req.nextUrl.searchParams;
  const filters = {
    tienda: sp.get('tienda') || undefined,
    buscar: sp.get('buscar') || undefined,
    gestor: sp.get('gestor') || undefined,
    cuestionario: sp.get('cuestionario') || undefined,
    desde: sp.get('desde') || undefined,
    hasta: sp.get('hasta') || undefined,
  };
  const { where } = await resolveFilters(session, filters);

  const submissions = await db.submission.findMany({
    where,
    include: {
      store: true,
      user: true,
      questionnaire: true,
      answers: { include: { field: true }, orderBy: { field: { order: 'asc' } } },
    },
    orderBy: { submittedAt: 'desc' },
  });

  const wb = new ExcelJS.Workbook();
  wb.creator = 'Panel interno Avanza Fibra';
  const ws = wb.addWorksheet('Respuestas');

  const base = [
    { header: 'Fecha', key: 'fecha', width: 12 },
    { header: 'Hora', key: 'hora', width: 8 },
    { header: 'Tienda', key: 'tienda', width: 14 },
    { header: 'Cuestionario', key: 'cuestionario', width: 30 },
    { header: 'Usuario', key: 'usuario', width: 26 },
    { header: 'Email', key: 'email', width: 30 },
    { header: 'Periodo', key: 'periodo', width: 12 },
    { header: 'En plazo', key: 'plazo', width: 10 },
  ];

  // Si se filtra por UN cuestionario, cada campo va en su propia columna;
  // con varios cuestionarios, las respuestas van resumidas en una columna.
  const singleQ = filters.cuestionario ? Number(filters.cuestionario) : null;
  let fieldCols: { id: number; label: string }[] = [];
  if (singleQ) {
    const fields = await db.field.findMany({ where: { questionnaireId: singleQ }, orderBy: { order: 'asc' } });
    fieldCols = fields.map((f) => ({ id: f.id, label: f.archived ? `${f.label} (retirado)` : f.label }));
    ws.columns = [...base, ...fieldCols.map((f) => ({ header: f.label, key: `f${f.id}`, width: 22 }))];
  } else {
    ws.columns = [...base, { header: 'Respuestas', key: 'respuestas', width: 80 }];
  }

  const answerText = (a: { value: string | null; filePath: string | null; field: { type: string } }) => {
    if (a.filePath) return `[foto: ${a.filePath}]`;
    if (a.field.type === 'CHECKBOX') return a.value === 'true' ? 'Sí' : 'No';
    return a.value ?? '';
  };

  for (const s of submissions) {
    const row: Record<string, string | number> = {
      fecha: s.submittedAt.toLocaleDateString('es-ES'),
      hora: s.submittedAt.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      tienda: s.store.name,
      cuestionario: s.questionnaire.title,
      usuario: s.user.name,
      email: s.user.email,
      periodo: s.periodKey,
      plazo: s.late ? 'No (tarde)' : 'Sí',
    };
    if (singleQ) {
      for (const a of s.answers) {
        const v = answerText(a);
        row[`f${a.fieldId}`] = a.field.type === 'NUMERO' && v !== '' ? Number(v) : v;
      }
    } else {
      row.respuestas = s.answers.map((a) => `${a.labelSnapshot}: ${answerText(a)}`).join(' | ');
    }
    ws.addRow(row);
  }

  // Estilo de cabecera con colores de marca
  ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF17304F' } };
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: ws.columnCount } };

  const buffer = await wb.xlsx.writeBuffer();
  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(Buffer.from(buffer), {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="respuestas_avanza_${stamp}.xlsx"`,
    },
  });
}
