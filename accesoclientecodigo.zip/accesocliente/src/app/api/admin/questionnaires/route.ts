import { NextRequest, NextResponse } from 'next/server';
import { apiSession, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import { validateQuestionnairePayload } from './validate';

// Crear cuestionario (RRHH, Gestor y Admin). Un gestor solo puede asignarlo
// a tiendas que tiene asignadas (validado en backend).
export async function POST(req: NextRequest) {
  const session = await apiSession('ADMIN', 'RRHH', 'GESTOR');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 });

  const body = await req.json();
  const parsed = validateQuestionnairePayload(body);
  if ('error' in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });

  const allowed = await visibleStoreIds(session);
  if (parsed.storeIds.some((id) => !allowed.includes(id))) {
    return NextResponse.json({ error: 'No puedes asignar cuestionarios a tiendas fuera de tu ámbito.' }, { status: 403 });
  }

  const q = await db.questionnaire.create({
    data: {
      title: parsed.title,
      description: parsed.description,
      frequency: parsed.frequency,
      deadlineTime: parsed.deadlineTime,
      createdById: session.id,
      stores: { create: parsed.storeIds.map((storeId) => ({ storeId })) },
      fields: {
        create: parsed.fields.map((f) => ({
          label: f.label,
          type: f.type,
          options: f.options.length ? JSON.stringify(f.options) : null,
          required: f.required,
          isCashAmount: f.isCashAmount,
          order: f.order,
        })),
      },
    },
  });
  return NextResponse.json({ ok: true, id: q.id });
}
