import { NextRequest, NextResponse } from 'next/server';
import { apiSession, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import { validateQuestionnairePayload } from '../validate';

// Editar un cuestionario SIN romper el histórico:
//  - los campos eliminados que ya tienen respuestas se archivan (archived=true)
//  - los campos sin respuestas se borran de verdad
//  - las respuestas guardan labelSnapshot, así que renombrar es seguro
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await apiSession('ADMIN', 'RRHH', 'GESTOR');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 });

  const id = Number(params.id);
  const existing = await db.questionnaire.findUnique({
    where: { id },
    include: { fields: { include: { _count: { select: { answers: true } } } } },
  });
  if (!existing) return NextResponse.json({ error: 'Cuestionario no encontrado.' }, { status: 404 });

  const body = await req.json();
  const parsed = validateQuestionnairePayload(body);
  if ('error' in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });

  const allowed = await visibleStoreIds(session);
  if (parsed.storeIds.some((sid) => !allowed.includes(sid))) {
    return NextResponse.json({ error: 'No puedes asignar cuestionarios a tiendas fuera de tu ámbito.' }, { status: 403 });
  }

  const incomingIds = parsed.fields.filter((f) => f.id).map((f) => f.id!);
  const ownFieldIds = existing.fields.map((f) => f.id);
  if (incomingIds.some((fid) => !ownFieldIds.includes(fid))) {
    return NextResponse.json({ error: 'Campo no válido para este cuestionario.' }, { status: 400 });
  }
  const removed = existing.fields.filter((f) => !f.archived && !incomingIds.includes(f.id));

  await db.$transaction([
    db.questionnaire.update({
      where: { id },
      data: {
        title: parsed.title,
        description: parsed.description,
        frequency: parsed.frequency,
        deadlineTime: parsed.deadlineTime,
      },
    }),
    // Reasignación de tiendas
    db.questionnaireStore.deleteMany({ where: { questionnaireId: id } }),
    db.questionnaireStore.createMany({ data: parsed.storeIds.map((storeId) => ({ questionnaireId: id, storeId })) }),
    // Campos eliminados: archivar si tienen respuestas, borrar si no
    ...removed.map((f) =>
      f._count.answers > 0
        ? db.field.update({ where: { id: f.id }, data: { archived: true } })
        : db.field.delete({ where: { id: f.id } })
    ),
    // Campos existentes: actualizar
    ...parsed.fields
      .filter((f) => f.id)
      .map((f) =>
        db.field.update({
          where: { id: f.id! },
          data: {
            label: f.label,
            options: f.options.length ? JSON.stringify(f.options) : null,
            required: f.required,
            isCashAmount: f.isCashAmount,
            order: f.order,
          },
        })
      ),
    // Campos nuevos: crear
    ...parsed.fields
      .filter((f) => !f.id)
      .map((f) =>
        db.field.create({
          data: {
            questionnaireId: id,
            label: f.label,
            type: f.type,
            options: f.options.length ? JSON.stringify(f.options) : null,
            required: f.required,
            isCashAmount: f.isCashAmount,
            order: f.order,
          },
        })
      ),
  ]);

  return NextResponse.json({ ok: true });
}

// Activar/desactivar. Desactivar NUNCA borra respuestas: el cuestionario deja
// de aparecer a los comerciales pero todo el histórico sigue consultable.
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await apiSession('ADMIN', 'RRHH', 'GESTOR');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 });
  const { active } = await req.json();
  await db.questionnaire.update({ where: { id: Number(params.id) }, data: { active: Boolean(active) } });
  return NextResponse.json({ ok: true });
}
