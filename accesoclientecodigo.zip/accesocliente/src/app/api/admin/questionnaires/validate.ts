const VALID_TYPES = ['TEXTO', 'NUMERO', 'SELECCION', 'FECHA', 'CHECKBOX', 'FOTO'];
const VALID_FREQ = ['DIARIO', 'SEMANAL', 'MENSUAL', 'PUNTUAL'];

export interface ParsedField {
  id?: number;
  label: string;
  type: string;
  options: string[];
  required: boolean;
  isCashAmount: boolean;
  order: number;
}

export interface ParsedQuestionnaire {
  title: string;
  description: string | null;
  frequency: string;
  deadlineTime: string | null;
  storeIds: number[];
  fields: ParsedField[];
}

export function validateQuestionnairePayload(body: any): ParsedQuestionnaire | { error: string } {
  const title = String(body?.title || '').trim();
  if (!title) return { error: 'El título es obligatorio.' };
  const frequency = String(body?.frequency || '');
  if (!VALID_FREQ.includes(frequency)) return { error: 'Frecuencia no válida.' };
  const deadlineTime =
    frequency === 'PUNTUAL' ? null : /^\d{2}:\d{2}$/.test(String(body?.deadlineTime || '')) ? String(body.deadlineTime) : null;
  const storeIds = Array.isArray(body?.storeIds) ? body.storeIds.map(Number).filter((n: number) => !Number.isNaN(n)) : [];
  if (storeIds.length === 0) return { error: 'Selecciona al menos una tienda.' };
  if (!Array.isArray(body?.fields) || body.fields.length === 0) return { error: 'Añade al menos un campo.' };

  const fields: ParsedField[] = [];
  for (const [i, f] of body.fields.entries()) {
    const label = String(f?.label || '').trim();
    if (!label) return { error: `El campo ${i + 1} no tiene etiqueta.` };
    const type = String(f?.type || '');
    if (!VALID_TYPES.includes(type)) return { error: `Tipo no válido en "${label}".` };
    const options = type === 'SELECCION' ? (Array.isArray(f.options) ? f.options.map(String).filter(Boolean) : []) : [];
    if (type === 'SELECCION' && options.length < 2) return { error: `"${label}": una selección necesita al menos 2 opciones.` };
    fields.push({
      id: f.id ? Number(f.id) : undefined,
      label,
      type,
      options,
      required: Boolean(f.required),
      isCashAmount: type === 'NUMERO' && Boolean(f.isCashAmount),
      order: i,
    });
  }
  return { title, description: String(body?.description || '').trim() || null, frequency, deadlineTime, storeIds, fields };
}
