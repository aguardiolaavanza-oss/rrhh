import fs from 'fs/promises';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { apiSession, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const MIME: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic',
};

// Las fotos adjuntas NO se sirven públicamente: se comprueba en cada descarga
// que quien la pide puede ver el envío al que pertenece.
//  - COMERCIAL: solo fotos de SUS envíos
//  - GESTOR: fotos de envíos de sus tiendas asignadas
//  - RRHH / ADMIN: todas
export async function GET(_req: NextRequest, { params }: { params: { name: string } }) {
  const session = await apiSession();
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 401 });

  const name = path.basename(params.name); // evita path traversal
  const answer = await db.answer.findFirst({ where: { filePath: name }, include: { submission: true } });
  if (!answer) return NextResponse.json({ error: 'No encontrado.' }, { status: 404 });

  if (session.role === 'COMERCIAL') {
    if (answer.submission.userId !== session.id) {
      return NextResponse.json({ error: 'Sin permiso.' }, { status: 403 });
    }
  } else {
    const stores = await visibleStoreIds(session);
    if (!stores.includes(answer.submission.storeId)) {
      return NextResponse.json({ error: 'Sin permiso.' }, { status: 403 });
    }
  }

  try {
    const data = await fs.readFile(path.join(UPLOAD_DIR, name));
    const ext = name.split('.').pop() || '';
    return new NextResponse(data, {
      headers: {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control': 'private, max-age=3600',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Archivo no disponible.' }, { status: 404 });
  }
}
