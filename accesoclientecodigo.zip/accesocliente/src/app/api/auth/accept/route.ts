import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { createSession, homeFor, Role } from '@/lib/auth';

// Aceptación de invitación (crear contraseña) y restablecimiento de contraseña.
// Ambos consumen un AuthToken de un solo uso.
export async function POST(req: NextRequest) {
  const { token, password } = await req.json();
  if (!token || typeof password !== 'string' || password.length < 8) {
    return NextResponse.json({ error: 'La contraseña debe tener al menos 8 caracteres.' }, { status: 400 });
  }
  const authToken = await db.authToken.findUnique({ where: { token }, include: { user: true } });
  if (!authToken || authToken.usedAt || authToken.expiresAt < new Date()) {
    return NextResponse.json({ error: 'El enlace no es válido o ha caducado. Solicita uno nuevo.' }, { status: 400 });
  }
  if (authToken.user.status === 'DESACTIVADO') {
    return NextResponse.json({ error: 'Esta cuenta está desactivada.' }, { status: 403 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await db.$transaction([
    db.user.update({ where: { id: authToken.userId }, data: { passwordHash, status: 'ACTIVO' } }),
    db.authToken.update({ where: { id: authToken.id }, data: { usedAt: new Date() } }),
    ...(authToken.type === 'INVITE'
      ? [db.invitation.updateMany({
          where: { userId: authToken.userId, acceptedAt: null },
          data: { acceptedAt: new Date() },
        })]
      : []),
  ]);

  await createSession(authToken.userId);
  return NextResponse.json({ ok: true, redirect: homeFor(authToken.user.role as Role) });
}
