import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { createSession, homeFor, Role } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();
  if (!email || !password) {
    return NextResponse.json({ error: 'Introduce email y contraseña.' }, { status: 400 });
  }
  const user = await db.user.findUnique({ where: { email: String(email).trim().toLowerCase() } });
  if (!user || !user.passwordHash || !(await bcrypt.compare(password, user.passwordHash))) {
    return NextResponse.json({ error: 'Email o contraseña incorrectos.' }, { status: 401 });
  }
  if (user.status === 'DESACTIVADO') {
    return NextResponse.json({ error: 'Tu cuenta está desactivada. Contacta con administración.' }, { status: 403 });
  }
  if (user.status === 'INVITADO') {
    return NextResponse.json({ error: 'Tu cuenta aún no está activada. Usa el enlace de invitación recibido por email.' }, { status: 403 });
  }
  await createSession(user.id);
  return NextResponse.json({ ok: true, redirect: homeFor(user.role as Role) });
}
