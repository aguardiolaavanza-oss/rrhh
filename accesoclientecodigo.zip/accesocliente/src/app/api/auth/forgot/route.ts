import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { sendResetEmail } from '@/lib/email';

export async function POST(req: NextRequest) {
  const { email } = await req.json();
  const user = await db.user.findUnique({ where: { email: String(email || '').trim().toLowerCase() } });
  // Respuesta idéntica exista o no la cuenta (no revelamos qué emails existen)
  if (user && user.status === 'ACTIVO') {
    await db.authToken.deleteMany({ where: { userId: user.id, type: 'RESET' } });
    const token = crypto.randomBytes(32).toString('hex');
    await db.authToken.create({
      data: { token, type: 'RESET', userId: user.id, expiresAt: new Date(Date.now() + 2 * 3600 * 1000) },
    });
    await sendResetEmail(user.email, user.name, token);
  }
  return NextResponse.json({ ok: true });
}
