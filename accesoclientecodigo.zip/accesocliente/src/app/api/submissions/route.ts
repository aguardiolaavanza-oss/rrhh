import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { apiSession } from '@/lib/auth';
import { db } from '@/lib/db';
import { Frequency, isLate, periodKey } from '@/lib/periods';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const MAX_FILE = 8 * 1024 * 1024; // 8 MB por foto

// Envío de un cuestionario por parte de un COMERCIAL.
// Reglas aplicadas en backend (no solo en UI):
//  - solo comerciales, y solo cuestionarios activos asignados a SU tienda
//  - un envío por tienda y periodo (salvo PUNTUAL)
//  - campos obligatorios validados, fotos guardadas fuera de /public
export async function POST(req: NextRequest) {
  const session = await apiSession('COMERCIAL');
  if (!session) return NextResponse.json({ error: 'No autorizado.' }, { status: 401 });
  const storeId = session.storeIds[0];
  if (!storeId) return NextResponse.json({ error: 'No tienes tienda asignada.' }, { status: 403 });

  const form = await req.formData();
  const questionnaireId = Number(form.get('questionnaireId'));
  const q = await db.questionnaire.findFirst({
    where: { id: questionnaireId, active: true, stores: { some: { storeId } } },
    include: { fields: { where: { archived: false } } },
  });
  if (!q) return NextResponse.json({ error: 'Cuestionario no disponible para tu tienda.' }, { status: 403 });

  const now = new Date();
  const freq = q.frequency as Frequency;
  const key = periodKey(freq, now);

  if (freq !== 'PUNTUAL') {
    const dup = await db.submission.findFirst({ where: { questionnaireId, storeId, periodKey: key } });
    if (dup) return NextResponse.json({ error: 'Este cuestionario ya se envió en el periodo actual.' }, { status: 409 });
  }

  // Validación y preparación de respuestas
  const answers: { fieldId: number; labelSnapshot: string; value?: string; filePath?: string }[] = [];
  const savedFiles: string[] = [];
  try {
    for (const f of q.fields) {
      const raw = form.get(`field_${f.id}`);
      if (f.type === 'FOTO') {
        const file = raw instanceof File && raw.size > 0 ? raw : null;
        if (!file && f.required) throw new Error(`Falta la foto obligatoria: "${f.label}".`);
        if (!file) { answers.push({ fieldId: f.id, labelSnapshot: f.label }); continue; }
        if (file.size > MAX_FILE) throw new Error(`La foto de "${f.label}" supera los 8 MB.`);
        if (!file.type.startsWith('image/')) throw new Error(`"${f.label}" debe ser una imagen.`);
        const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
        const name = `${crypto.randomBytes(16).toString('hex')}.${ext}`;
        await fs.mkdir(UPLOAD_DIR, { recursive: true });
        await fs.writeFile(path.join(UPLOAD_DIR, name), Buffer.from(await file.arrayBuffer()));
        savedFiles.push(name);
        answers.push({ fieldId: f.id, labelSnapshot: f.label, filePath: name });
        continue;
      }
      const value = typeof raw === 'string' ? raw.trim() : '';
      if (f.type === 'CHECKBOX') {
        answers.push({ fieldId: f.id, labelSnapshot: f.label, value: value === 'true' ? 'true' : 'false' });
        continue;
      }
      if (!value && f.required) throw new Error(`El campo "${f.label}" es obligatorio.`);
      if (value && f.type === 'NUMERO' && Number.isNaN(Number(value))) {
        throw new Error(`El campo "${f.label}" debe ser un número.`);
      }
      if (value && f.type === 'SELECCION') {
        const opts: string[] = f.options ? JSON.parse(f.options) : [];
        if (!opts.includes(value)) throw new Error(`Valor no válido en "${f.label}".`);
      }
      answers.push({ fieldId: f.id, labelSnapshot: f.label, value });
    }
  } catch (e) {
    await Promise.all(savedFiles.map((n) => fs.unlink(path.join(UPLOAD_DIR, n)).catch(() => {})));
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Datos no válidos.' }, { status: 400 });
  }

  const submission = await db.submission.create({
    data: {
      questionnaireId,
      storeId,
      userId: session.id,
      periodKey: key,
      submittedAt: now,
      late: isLate(freq, q.deadlineTime, now),
      answers: { create: answers },
    },
  });

  return NextResponse.json({ ok: true, id: submission.id });
}
