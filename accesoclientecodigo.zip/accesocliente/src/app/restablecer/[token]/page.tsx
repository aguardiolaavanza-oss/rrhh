import { db } from '@/lib/db';
import SetPasswordForm from '@/components/SetPasswordForm';

export const dynamic = 'force-dynamic';

export default async function ResetPage({ params }: { params: { token: string } }) {
  const authToken = await db.authToken.findUnique({ where: { token: params.token } });
  const valid = authToken && authToken.type === 'RESET' && !authToken.usedAt && authToken.expiresAt > new Date();

  return (
    <div className="authwrap">
      <div className="authcard">
        <div className="logo">
          <strong>avanza <em>fibra</em></strong>
          <span>Restablecer contraseña</span>
        </div>
        {!valid ? (
          <div className="msg err">Este enlace no es válido o ha caducado. Solicita uno nuevo desde “¿Has olvidado tu contraseña?”.</div>
        ) : (
          <SetPasswordForm token={params.token} cta="Guardar nueva contraseña" />
        )}
      </div>
    </div>
  );
}
