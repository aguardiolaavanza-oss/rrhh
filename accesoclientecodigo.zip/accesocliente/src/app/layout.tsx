import type { Metadata, Viewport } from 'next';
import '@fontsource-variable/urbanist';
import './globals.css';

export const metadata: Metadata = {
  title: 'Avanza Fibra · Panel interno',
  description: 'Panel interno de cuestionarios y control de tiendas — TELYRA TELECOM S.L.',
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
