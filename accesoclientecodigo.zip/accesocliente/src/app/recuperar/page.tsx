'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ForgotPage() {
  const [sent, setSent] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    await fetch('/api/auth/forgot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: form.get('email') }),
    });
    setSent(true);
  }

  return (
    <div className="authwrap">
      <div className="authcard">
        <div className="logo">
          <strong>avanza <em>fibra</em></strong>
          <span>Recuperar contraseña</span>
        </div>
        {sent ? (
          <div className="msg ok">
            Si existe una cuenta con ese email, recibirás un enlace para restablecer tu contraseña (caduca en 2 horas).
          </div>
        ) : (
          <form onSubmit={onSubmit}>
            <label className="f"><span>Tu email</span>
              <input name="email" type="email" required placeholder="tu@avanzafibra.com" />
            </label>
            <button className="btn orange" style={{ width: '100%', justifyContent: 'center' }}>Enviar enlace</button>
          </form>
        )}
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: 13 }}><Link href="/login">Volver al inicio de sesión</Link></p>
      </div>
    </div>
  );
}
