import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { AdminFilters, resolveFilters } from '@/lib/adminFilters';
import { dateKey, Frequency, periodKey, periodStatus } from '@/lib/periods';
import FiltersBar from '@/components/FiltersBar';
import BarChart from '@/components/BarChart';
import DonutChart from '@/components/DonutChart';
import SpainMap, { MapStore } from '@/components/SpainMap';
import StatusBadge from '@/components/StatusBadge';

export const dynamic = 'force-dynamic';

// Dashboard de administración: KPIs + evolución temporal + semáforo del
// periodo actual + tabla de detalle. Todo respeta el alcance por rol
// (gestor: solo sus tiendas) y los filtros combinables de la barra superior.
export default async function AdminDashboard({ searchParams }: { searchParams: AdminFilters }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const { where, storeIds, allVisibleStores } = await resolveFilters(session, searchParams);

  const questionnaires = await db.questionnaire.findMany({ orderBy: { title: 'asc' } });
  const gestores =
    session.role === 'GESTOR'
      ? undefined
      : await db.user.findMany({ where: { role: 'GESTOR' }, orderBy: { name: 'asc' }, select: { id: true, name: true } });

  const submissions = await db.submission.findMany({
    where,
    include: {
      store: true,
      user: true,
      questionnaire: true,
      answers: { where: { field: { isCashAmount: true } } },
    },
    orderBy: { submittedAt: 'desc' },
  });

  // KPIs
  const total = submissions.length;
  const onTime = submissions.filter((s) => !s.late).length;
  const cash = submissions.reduce(
    (sum, s) => sum + s.answers.reduce((a, ans) => a + (Number(ans.value) || 0), 0),
    0
  );

  // Donut: distribución de respuestas por tienda (con los filtros actuales)
  const donutData = allVisibleStores
    .map((st) => ({ label: st.name, value: submissions.filter((s) => s.storeId === st.id).length }))
    .filter((d) => d.value > 0);

  // Mapa de España: datos por tienda de TODO el ámbito visible (aplica
  // cuestionario/gestor/fechas pero no el filtro de tienda, para que el mapa
  // siga sirviendo de navegación entre tiendas).
  const mapSubmissions = await db.submission.findMany({
    where: { ...where, storeId: { in: allVisibleStores.map((s) => s.id) } },
    select: { storeId: true, answers: { where: { field: { isCashAmount: true } }, select: { value: true } } },
  });
  const mapStores: MapStore[] = allVisibleStores.map((st) => {
    const subs = mapSubmissions.filter((s) => s.storeId === st.id);
    return {
      id: st.id,
      name: st.name,
      submissions: subs.length,
      cash: subs.reduce((a, s) => a + s.answers.reduce((x, ans) => x + (Number(ans.value) || 0), 0), 0),
    };
  });

  // Semáforo del periodo actual: estado de cada cuestionario activo en cada
  // tienda visible/filtrada (sin filtro de fechas: es el "ahora").
  const now = new Date();
  const activeQs = questionnaires.filter(
    (q) => q.active && q.frequency !== 'PUNTUAL' && (!searchParams.cuestionario || q.id === Number(searchParams.cuestionario))
  );
  const qStores = await db.questionnaireStore.findMany({ where: { questionnaireId: { in: activeQs.map((q) => q.id) } } });
  const semaforo: { store: string; q: string; status: ReturnType<typeof periodStatus> }[] = [];
  for (const q of activeQs) {
    const applies = qStores.filter((s) => s.questionnaireId === q.id).map((s) => s.storeId);
    for (const store of allVisibleStores.filter((s) => storeIds.includes(s.id) && applies.includes(s.id))) {
      const key = periodKey(q.frequency as Frequency, now);
      const sub = await db.submission.findFirst({
        where: { questionnaireId: q.id, storeId: store.id, periodKey: key },
      });
      semaforo.push({
        store: store.name,
        q: q.title,
        status: periodStatus(q.frequency as Frequency, q.deadlineTime, sub ? { late: sub.late } : null, now),
      });
    }
  }
  const vencidos = semaforo.filter((s) => s.status === 'VENCIDO').length;

  // Evolución temporal: respuestas por día (últimos 30 días o rango filtrado)
  const chartDays = 30;
  const start = searchParams.desde ? new Date(`${searchParams.desde}T00:00:00`) : new Date(now.getTime() - (chartDays - 1) * 86400000);
  const end = searchParams.hasta ? new Date(`${searchParams.hasta}T00:00:00`) : now;
  const byDay = new Map<string, number>();
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) byDay.set(dateKey(d), 0);
  for (const s of submissions) {
    const k = dateKey(s.submittedAt);
    if (byDay.has(k)) byDay.set(k, (byDay.get(k) || 0) + 1);
  }
  const chartData = [...byDay.entries()].map(([k, v]) => ({ label: k.slice(5), value: v }));

  const eur = (n: number) => n.toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Dashboard</h1>
          <p>Resumen de respuestas por tienda, cuestionario y fecha.</p>
        </div>
      </div>

      <FiltersBar
        stores={allVisibleStores}
        questionnaires={questionnaires.map((q) => ({ id: q.id, name: q.title }))}
        gestores={gestores}
        exportPath="/api/admin/export"
      />

      <div className="kpis">
        <div className="card kpi grad g-navy"><div className="icon">📋</div><div><div className="num">{total}</div><div className="lbl">Respuestas (filtro actual)</div></div></div>
        <div className="card kpi grad g-blue"><div className="icon">⏱️</div><div><div className="num">{total ? Math.round((onTime / total) * 100) : 100}%</div><div className="lbl">Enviadas en plazo</div></div></div>
        <div className={`card kpi grad ${vencidos ? 'g-red' : 'g-gray'}`}><div className="icon">🚨</div><div><div className="num">{vencidos}</div><div className="lbl">Vencidos ahora mismo</div></div></div>
        <div className="card kpi grad g-orange"><div className="icon">💶</div><div><div className="num">{eur(cash)}</div><div className="lbl">Recaudación (conteos de caja)</div></div></div>
      </div>

      <div className="grid2">
        <div className="card">
          <h2>Evolución de respuestas por día</h2>
          <BarChart data={chartData} />
        </div>
        <div className="card">
          <h2>Respuestas por tienda</h2>
          <DonutChart data={donutData} centerLabel="respuestas" />
        </div>
      </div>

      <div className="grid2 mt">
        <div className="card">
          <h2>Tiendas en España</h2>
          <p className="muted" style={{ marginTop: 0 }}>Recaudación acumulada por tienda con los filtros actuales.</p>
          <SpainMap stores={mapStores} />
        </div>
        <div className="card">
          <h2>Semáforo del periodo actual</h2>
          <p className="muted" style={{ marginTop: 0 }}>Cuestionarios recurrentes activos por tienda.</p>
          <div className="tablewrap">
            <table className="data">
              <thead><tr><th>Tienda</th><th>Cuestionario</th><th>Estado</th></tr></thead>
              <tbody>
                {semaforo.map((s, i) => (
                  <tr key={i}>
                    <td>{s.store}</td>
                    <td>{s.q}</td>
                    <td><StatusBadge status={s.status} /></td>
                  </tr>
                ))}
                {semaforo.length === 0 && <tr><td colSpan={3} className="muted">Sin cuestionarios recurrentes en el filtro actual.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="card mt">
        <div className="row mb">
          <h2>Detalle de respuestas</h2>
          <span className="spacer" />
          <span className="muted">{total} resultados · mostrando {Math.min(total, 50)}</span>
        </div>
        <div className="tablewrap">
          <table className="data dark">
            <thead>
              <tr><th>Fecha y hora</th><th>Tienda</th><th>Cuestionario</th><th>Usuario</th><th>Periodo</th><th>Plazo</th><th className="num">Importe caja</th><th></th></tr>
            </thead>
            <tbody>
              {submissions.slice(0, 50).map((s) => {
                const amount = s.answers.reduce((a, ans) => a + (Number(ans.value) || 0), 0);
                return (
                  <tr key={s.id}>
                    <td>{s.submittedAt.toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                    <td>{s.store.name}</td>
                    <td>{s.questionnaire.title}</td>
                    <td>{s.user.name}</td>
                    <td><code className="k">{s.periodKey}</code></td>
                    <td>{s.late ? <span className="badge warn">Tarde</span> : <span className="badge ok">En plazo</span>}</td>
                    <td className="num">{s.answers.length ? eur(amount) : '—'}</td>
                    <td><Link href={`/admin/historial/${s.id}`}>Ver</Link></td>
                  </tr>
                );
              })}
              {total === 0 && <tr><td colSpan={8} className="muted">Sin respuestas con los filtros actuales.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
