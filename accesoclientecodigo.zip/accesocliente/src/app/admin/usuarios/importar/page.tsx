import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import ImportUsers from '@/components/ImportUsers';

export const dynamic = 'force-dynamic';

export default async function ImportPage() {
  await requireRole('ADMIN');
  return (
    <>
      <p><Link href="/admin/usuarios">← Gestión de accesos</Link></p>
      <div className="pagehead">
        <div>
          <h1>Importación masiva de usuarios</h1>
          <p>
            Sube un Excel con columnas <code className="k">nombre</code>, <code className="k">email</code>,{' '}
            <code className="k">rol</code> y <code className="k">tienda</code>. Cada fila se valida por separado.
          </p>
        </div>
        <a className="btn ghost" href="/api/admin/users/template" download>⬇ Descargar plantilla</a>
      </div>
      <ImportUsers />
    </>
  );
}
