import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import NewUserButton from '@/components/NewUserButton';
import UserRow, { UserRowData } from '@/components/UserRow';
import UsersFilters from '@/components/UsersFilters';

export const dynamic = 'force-dynamic';

// Gestión de accesos: SOLO la administradora principal.
export default async function UsersPage({
  searchParams,
}: {
  searchParams: { rol?: string; tienda?: string; estado?: string; buscar?: string };
}) {
  const session = await requireRole('ADMIN');

  const stores = await db.store.findMany({ orderBy: { name: 'asc' } });
  const users = await db.user.findMany({
    where: {
      ...(searchParams.rol ? { role: searchParams.rol } : {}),
      ...(searchParams.estado ? { status: searchParams.estado } : {}),
      ...(searchParams.tienda ? { stores: { some: { storeId: Number(searchParams.tienda) } } } : {}),
      ...(searchParams.buscar
        ? { OR: [{ name: { contains: searchParams.buscar } }, { email: { contains: searchParams.buscar } }] }
        : {}),
    },
    include: {
      stores: { include: { store: true } },
      invitations: { orderBy: { sentAt: 'desc' }, take: 1, include: { sentBy: true } },
    },
    orderBy: [{ status: 'asc' }, { name: 'asc' }],
  });

  const rows: UserRowData[] = users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    storeIds: u.stores.map((s) => s.storeId),
    storeNames: u.stores.map((s) => s.store.name).join(', '),
    status: u.status,
    lastInvite: u.invitations[0]
      ? `${u.invitations[0].sentAt.toLocaleDateString('es-ES')}${u.invitations[0].sentBy ? ` por ${u.invitations[0].sentBy.name}` : ''}${u.invitations[0].acceptedAt ? ' · aceptada' : ''}`
      : null,
    isSelf: u.id === session.id,
  }));

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Gestión de accesos</h1>
          <p>Alta de usuarios, roles, tiendas asignadas, invitaciones y revocación de acceso.</p>
        </div>
        <div className="row">
          <a className="btn ghost" href="/api/admin/users/template" download>⬇ Plantilla Excel</a>
          <Link className="btn" href="/admin/usuarios/importar">Importación masiva</Link>
        </div>
      </div>

      <NewUserButton stores={stores} />

      <div className="mt">
        <UsersFilters stores={stores} />
      </div>

      <div className="card">
        <div className="tablewrap">
          <table className="data">
            <thead>
              <tr><th>Nombre</th><th>Email</th><th>Rol</th><th>Tienda(s)</th><th>Estado</th><th>Última invitación</th><th>Acciones</th></tr>
            </thead>
            <tbody>
              {rows.map((u) => <UserRow key={u.id} user={u} stores={stores} />)}
              {rows.length === 0 && <tr><td colSpan={7} className="muted">Sin usuarios con los filtros actuales.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
