import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

// Ranking de recaudación por gestor: para cada gestor, sus tiendas asignadas
// ordenadas por importe acumulado (campo de caja isCashAmount de los conteos),
// destacando la tienda con más efectivo pendiente de recoger.
// Un GESTOR solo ve su propio ranking; ADMIN/RRHH ven el de todos los gestores.
export default async function RankingPage({
  searchParams,
}: {
  searchParams: { desde?: string; hasta?: string };
}) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');

  // Rango de fechas (por defecto: últimos 30 días)
  const to = searchParams.hasta ? new Date(`${searchParams.hasta}T23:59:59.999`) : new Date();
  const from = searchParams.desde
    ? new Date(`${searchParams.desde}T00:00:00`)
    : new Date(to.getTime() - 30 * 86400000);

  const gestores =
    session.role === 'GESTOR'
      ? await db.user.findMany({ where: { id: session.id }, include: { stores: { include: { store: true } } } })
      : await db.user.findMany({
          where: { role: 'GESTOR', status: { not: 'DESACTIVADO' } },
          include: { stores: { include: { store: true } } },
          orderBy: { name: 'asc' },
        });

  // Suma de los campos de caja por tienda, dentro del rango y limitada a las
  // tiendas de los gestores visibles (un gestor nunca consulta otras tiendas)
  const allowedStoreIds = [...new Set(gestores.flatMap((g) => g.stores.map((s) => s.storeId)))];
  const cashAnswers = await db.answer.findMany({
    where: {
      field: { isCashAmount: true },
      submission: { submittedAt: { gte: from, lte: to }, storeId: { in: allowedStoreIds } },
    },
    include: { submission: true },
  });
  const byStore = new Map<number, { total: number; count: number; last: Date | null }>();
  for (const a of cashAnswers) {
    const cur = byStore.get(a.submission.storeId) || { total: 0, count: 0, last: null };
    cur.total += Number(a.value) || 0;
    cur.count += 1;
    if (!cur.last || a.submission.submittedAt > cur.last) cur.last = a.submission.submittedAt;
    byStore.set(a.submission.storeId, cur);
  }

  const eur = (n: number) => n.toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const fmtDay = (d: Date) => d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Ranking de recaudación</h1>
          <p>
            Importe acumulado en conteos de caja del {fmtDay(from)} al {fmtDay(to)}. La tienda destacada es la
            prioridad de recogida de efectivo.
          </p>
        </div>
      </div>

      <form className="filters card" style={{ padding: '14px 16px' }} method="get">
        <label className="f"><span>Desde</span><input type="date" name="desde" defaultValue={searchParams.desde || ''} /></label>
        <label className="f"><span>Hasta</span><input type="date" name="hasta" defaultValue={searchParams.hasta || ''} /></label>
        <button className="btn sm">Aplicar</button>
      </form>

      {gestores.map((g) => {
        const rows = g.stores
          .map(({ store }) => ({ store, ...(byStore.get(store.id) || { total: 0, count: 0, last: null }) }))
          .sort((a, b) => b.total - a.total);
        const max = Math.max(1, ...rows.map((r) => r.total));
        return (
          <div className="card mb" key={g.id}>
            <div className="row">
              <h2>{g.name}</h2>
              <span className="badge info plain">{g.stores.length} tienda(s) asignada(s)</span>
            </div>
            {rows.length === 0 && <p className="muted">Este gestor no tiene tiendas asignadas.</p>}
            {rows.map((r, i) => (
              <div className={`rankrow ${i === 0 && r.total > 0 ? 'top' : ''}`} key={r.store.id}>
                <div className="pos">{i + 1}</div>
                <div style={{ minWidth: 130 }}>
                  <strong style={{ color: 'var(--navy)' }}>{r.store.name}</strong>
                  {i === 0 && r.total > 0 && (
                    <span className="badge warn plain" style={{ marginLeft: 8, background: 'var(--orange)', color: '#fff' }}>
                      ⭐ Prioridad de recogida
                    </span>
                  )}
                  <div className="muted">
                    {r.count} conteo(s){r.last && <> · último: {fmtDay(r.last)}</>}
                  </div>
                </div>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${(r.total / max) * 100}%` }} /></div>
                <div className="amount">{eur(r.total)}</div>
              </div>
            ))}
          </div>
        );
      })}
    </>
  );
}
