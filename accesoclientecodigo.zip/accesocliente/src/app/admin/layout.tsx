import { requireRole } from '@/lib/auth';
import LogoutButton from '@/components/LogoutButton';
import SidebarNav from '@/components/SidebarNav';

export const dynamic = 'force-dynamic';

const ROLE_LABEL: Record<string, string> = {
  ADMIN: 'Administradora',
  RRHH: 'RRHH',
  GESTOR: 'Gestor',
};

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <strong>avanza <span style={{ color: 'var(--orange)' }}>fibra</span></strong>
          <span>TELYRA TELECOM · Panel interno</span>
        </div>
        <SidebarNav isAdmin={session.role === 'ADMIN'} />
        <div className="userbox">
          <div className="name">{session.name}</div>
          <div className="role">{ROLE_LABEL[session.role]}</div>
          <div style={{ marginTop: 8 }}><LogoutButton /></div>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
