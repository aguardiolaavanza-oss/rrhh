import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireRole, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import SubmissionDetail from '@/components/SubmissionDetail';

export const dynamic = 'force-dynamic';

export default async function AdminSubmissionPage({ params }: { params: { sid: string } }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const visible = await visibleStoreIds(session);

  // El envío debe pertenecer a una tienda dentro del ámbito del usuario
  const submission = await db.submission.findFirst({
    where: { id: Number(params.sid), storeId: { in: visible } },
    include: { questionnaire: true, store: true, user: true, answers: { include: { field: true } } },
  });
  if (!submission) notFound();

  return (
    <>
      <p><Link href="/admin/historial">← Volver al histórico</Link></p>
      <SubmissionDetail submission={submission} />
    </>
  );
}
