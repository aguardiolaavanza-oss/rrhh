import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { AdminFilters, resolveFilters } from '@/lib/adminFilters';
import FiltersBar from '@/components/FiltersBar';

export const dynamic = 'force-dynamic';

// Auditoría: quién respondió qué y cuándo, con acceso al detalle completo.
// Mismo motor de filtros que el dashboard y que la exportación a Excel.
export default async function HistoryPage({ searchParams }: { searchParams: AdminFilters & { pagina?: string } }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const { where, allVisibleStores } = await resolveFilters(session, searchParams);

  const PAGE = 25;
  const page = Math.max(1, Number(searchParams.pagina) || 1);
  const [total, submissions] = await Promise.all([
    db.submission.count({ where }),
    db.submission.findMany({
      where,
      include: { store: true, user: true, questionnaire: true },
      orderBy: { submittedAt: 'desc' },
      skip: (page - 1) * PAGE,
      take: PAGE,
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PAGE));

  const questionnaires = await db.questionnaire.findMany({ orderBy: { title: 'asc' } });
  const gestores =
    session.role === 'GESTOR'
      ? undefined
      : await db.user.findMany({ where: { role: 'GESTOR' }, orderBy: { name: 'asc' }, select: { id: true, name: true } });

  const pageLink = (p: number) => {
    const params = new URLSearchParams(searchParams as Record<string, string>);
    params.set('pagina', String(p));
    return `/admin/historial?${params.toString()}`;
  };

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Histórico y auditoría</h1>
          <p>Registro completo de envíos: quién respondió qué, cuándo y desde qué tienda.</p>
        </div>
      </div>

      <FiltersBar
        stores={allVisibleStores}
        questionnaires={questionnaires.map((q) => ({ id: q.id, name: q.title }))}
        gestores={gestores}
        exportPath="/api/admin/export"
      />

      <div className="card">
        <div className="tablewrap">
          <table className="data">
            <thead>
              <tr><th>Fecha y hora</th><th>Tienda</th><th>Cuestionario</th><th>Usuario</th><th>Periodo</th><th>Plazo</th><th></th></tr>
            </thead>
            <tbody>
              {submissions.map((s) => (
                <tr key={s.id}>
                  <td>{s.submittedAt.toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                  <td>{s.store.name}</td>
                  <td>{s.questionnaire.title}</td>
                  <td>{s.user.name}</td>
                  <td><code className="k">{s.periodKey}</code></td>
                  <td>{s.late ? <span className="badge warn">Tarde</span> : <span className="badge ok">En plazo</span>}</td>
                  <td><Link href={`/admin/historial/${s.id}`}>Ver detalle</Link></td>
                </tr>
              ))}
              {total === 0 && <tr><td colSpan={7} className="muted">Sin envíos con los filtros actuales.</td></tr>}
            </tbody>
          </table>
        </div>
        {pages > 1 && (
          <div className="row mt">
            {page > 1 && <Link className="btn ghost sm" href={pageLink(page - 1)}>← Anterior</Link>}
            <span className="muted">Página {page} de {pages} · {total} envíos</span>
            {page < pages && <Link className="btn ghost sm" href={pageLink(page + 1)}>Siguiente →</Link>}
          </div>
        )}
      </div>
    </>
  );
}
