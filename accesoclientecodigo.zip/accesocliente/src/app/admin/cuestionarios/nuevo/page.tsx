import { requireRole, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import QuestionnaireBuilder from '@/components/QuestionnaireBuilder';

export const dynamic = 'force-dynamic';

export default async function NewQuestionnairePage() {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const visible = await visibleStoreIds(session);
  const stores = await db.store.findMany({ where: { id: { in: visible }, active: true }, orderBy: { name: 'asc' } });

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Nuevo cuestionario</h1>
          <p>Define título, campos, tiendas, frecuencia y hora límite. Sin tocar código.</p>
        </div>
      </div>
      <QuestionnaireBuilder stores={stores} />
    </>
  );
}
