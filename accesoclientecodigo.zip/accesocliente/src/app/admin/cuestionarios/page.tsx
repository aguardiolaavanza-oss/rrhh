import Link from 'next/link';
import { requireRole, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import { Frequency, FREQUENCY_LABELS } from '@/lib/periods';
import ToggleActiveButton from '@/components/ToggleActiveButton';

export const dynamic = 'force-dynamic';

export default async function QuestionnairesPage({ searchParams }: { searchParams: { guardado?: string } }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const visible = await visibleStoreIds(session);

  // Un gestor ve los cuestionarios que aplican a alguna de sus tiendas
  const questionnaires = await db.questionnaire.findMany({
    where: session.role === 'GESTOR' ? { stores: { some: { storeId: { in: visible } } } } : {},
    include: {
      stores: { include: { store: true } },
      _count: { select: { submissions: true, fields: true } },
    },
    orderBy: [{ active: 'desc' }, { title: 'asc' }],
  });

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Cuestionarios</h1>
          <p>Crea, edita o desactiva cuestionarios sin perder el histórico de respuestas.</p>
        </div>
        <Link className="btn orange" href="/admin/cuestionarios/nuevo">+ Nuevo cuestionario</Link>
      </div>

      {searchParams.guardado && <div className="msg ok">Cuestionario guardado correctamente.</div>}

      <div className="card">
        <div className="tablewrap">
          <table className="data">
            <thead>
              <tr><th>Título</th><th>Frecuencia</th><th>Hora límite</th><th>Tiendas</th><th className="num">Campos</th><th className="num">Respuestas</th><th>Estado</th><th></th></tr>
            </thead>
            <tbody>
              {questionnaires.map((q) => (
                <tr key={q.id}>
                  <td style={{ fontWeight: 600, color: 'var(--navy)' }}>{q.title}</td>
                  <td>{FREQUENCY_LABELS[q.frequency as Frequency]}</td>
                  <td>{q.deadlineTime || '—'}</td>
                  <td>{q.stores.map((s) => s.store.name).join(', ')}</td>
                  <td className="num">{q._count.fields}</td>
                  <td className="num">{q._count.submissions}</td>
                  <td>{q.active ? <span className="badge ok">Activo</span> : <span className="badge muted">Desactivado</span>}</td>
                  <td>
                    <div className="row" style={{ flexWrap: 'nowrap' }}>
                      <Link className="btn ghost sm" href={`/admin/cuestionarios/${q.id}`}>Editar</Link>
                      <ToggleActiveButton id={q.id} active={q.active} />
                    </div>
                  </td>
                </tr>
              ))}
              {questionnaires.length === 0 && <tr><td colSpan={8} className="muted">Aún no hay cuestionarios.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
