import { notFound } from 'next/navigation';
import { requireRole, visibleStoreIds } from '@/lib/auth';
import { db } from '@/lib/db';
import QuestionnaireBuilder, { BuilderInitial } from '@/components/QuestionnaireBuilder';

export const dynamic = 'force-dynamic';

export default async function EditQuestionnairePage({ params }: { params: { id: string } }) {
  const session = await requireRole('ADMIN', 'RRHH', 'GESTOR');
  const visible = await visibleStoreIds(session);
  const stores = await db.store.findMany({ where: { id: { in: visible }, active: true }, orderBy: { name: 'asc' } });

  const q = await db.questionnaire.findUnique({
    where: { id: Number(params.id) },
    include: {
      stores: true,
      fields: { where: { archived: false }, orderBy: { order: 'asc' }, include: { _count: { select: { answers: true } } } },
      _count: { select: { submissions: true } },
    },
  });
  if (!q) notFound();

  const initial: BuilderInitial = {
    id: q.id,
    title: q.title,
    description: q.description || '',
    frequency: q.frequency,
    deadlineTime: q.deadlineTime || '21:00',
    storeIds: q.stores.map((s) => s.storeId),
    fields: q.fields.map((f) => ({
      id: f.id,
      label: f.label,
      type: f.type,
      optionsText: f.options ? (JSON.parse(f.options) as string[]).join('; ') : '',
      required: f.required,
      isCashAmount: f.isCashAmount,
      hasAnswers: f._count.answers > 0,
    })),
  };

  return (
    <>
      <div className="pagehead">
        <div>
          <h1>Editar: {q.title}</h1>
          <p>
            {q._count.submissions} respuestas registradas. Editar no borra el histórico: los campos con respuestas
            se retiran (no se eliminan) y las respuestas antiguas conservan su texto original.
          </p>
        </div>
      </div>
      <QuestionnaireBuilder stores={stores} initial={initial} />
    </>
  );
}
