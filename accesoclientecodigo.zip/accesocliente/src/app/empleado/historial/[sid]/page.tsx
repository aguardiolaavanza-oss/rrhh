import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import SubmissionDetail from '@/components/SubmissionDetail';

export const dynamic = 'force-dynamic';

export default async function MySubmissionPage({
  params,
  searchParams,
}: {
  params: { sid: string };
  searchParams: { enviado?: string };
}) {
  const session = await requireRole('COMERCIAL');
  // Un comercial SOLO puede abrir envíos hechos por él mismo
  const submission = await db.submission.findFirst({
    where: { id: Number(params.sid), userId: session.id },
    include: { questionnaire: true, store: true, user: true, answers: { include: { field: true } } },
  });
  if (!submission) notFound();

  return (
    <>
      <p><Link href="/empleado/historial">← Mi historial</Link></p>
      {searchParams.enviado && <div className="msg ok">Cuestionario enviado correctamente. Gracias.</div>}
      <SubmissionDetail submission={submission} />
    </>
  );
}
