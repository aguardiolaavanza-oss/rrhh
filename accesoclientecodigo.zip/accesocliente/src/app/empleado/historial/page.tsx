import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

// Historial PROPIO del comercial: solo sus envíos, solo lectura.
export default async function MyHistory() {
  const session = await requireRole('COMERCIAL');
  const submissions = await db.submission.findMany({
    where: { userId: session.id },
    include: { questionnaire: true, store: true },
    orderBy: { submittedAt: 'desc' },
    take: 100,
  });

  return (
    <>
      <h1 style={{ marginBottom: 12 }}>Mi historial</h1>
      {submissions.length === 0 && <div className="msg info">Aún no has enviado ningún cuestionario.</div>}
      {submissions.map((s) => (
        <div className="card qitem" key={s.id}>
          <div>
            <div className="ttl">{s.questionnaire.title}</div>
            <div className="sub">
              {s.submittedAt.toLocaleString('es-ES', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
              {' · '}
              {s.late ? <span className="badge warn">Fuera de plazo</span> : <span className="badge ok">En plazo</span>}
            </div>
          </div>
          <Link className="btn ghost sm" href={`/empleado/historial/${s.id}`}>Ver</Link>
        </div>
      ))}
    </>
  );
}
