import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { Frequency, FREQUENCY_LABELS, periodDeadline, periodKey, periodStatus } from '@/lib/periods';
import StatusBadge from '@/components/StatusBadge';

export const dynamic = 'force-dynamic';

// Lista de cuestionarios de la tienda del comercial con su estado en el
// periodo actual. "Completado" se calcula a nivel de tienda (si un compañero
// ya envió el conteo de hoy, no debe duplicarse), pero nunca se muestra el
// contenido de envíos de otros usuarios.
export default async function EmployeeHome() {
  const session = await requireRole('COMERCIAL');
  const storeId = session.storeIds[0];
  if (!storeId) return <div className="msg err">No tienes tienda asignada. Contacta con administración.</div>;

  const questionnaires = await db.questionnaire.findMany({
    where: { active: true, stores: { some: { storeId } } },
    orderBy: { title: 'asc' },
  });

  const now = new Date();
  const items = await Promise.all(
    questionnaires.map(async (q) => {
      const freq = q.frequency as Frequency;
      const key = periodKey(freq, now);
      const submission =
        freq === 'PUNTUAL'
          ? null // los puntuales se pueden enviar siempre
          : await db.submission.findFirst({
              where: { questionnaireId: q.id, storeId, periodKey: key },
              orderBy: { submittedAt: 'desc' },
            });
      const status = periodStatus(freq, q.deadlineTime, submission ? { late: submission.late } : null, now);
      const deadline = periodDeadline(freq, q.deadlineTime, now);
      return { q, status, deadline, submission, mine: submission?.userId === session.id };
    })
  );

  const pending = items.filter((i) => !i.submission);
  const done = items.filter((i) => i.submission);
  const fmt = (d: Date) =>
    d.toLocaleString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <div className="section">
        <h2 style={{ marginBottom: 10 }}>Pendientes</h2>
        {pending.length === 0 && <div className="msg ok">No tienes cuestionarios pendientes. ¡Todo al día!</div>}
        {pending.map(({ q, status, deadline }) => (
          <div className="card qitem" key={q.id}>
            <div>
              <div className="ttl">{q.title}</div>
              <div className="sub">
                {FREQUENCY_LABELS[q.frequency as Frequency]}
                {deadline && <> · Plazo: {fmt(deadline)}</>}
              </div>
              <div style={{ marginTop: 6 }}><StatusBadge status={status} /></div>
            </div>
            <Link className="btn orange sm" href={`/empleado/cuestionario/${q.id}`}>Rellenar</Link>
          </div>
        ))}
      </div>

      {done.length > 0 && (
        <div className="section">
          <h2 style={{ marginBottom: 10 }}>Completados en el periodo actual</h2>
          {done.map(({ q, status, submission, mine }) => (
            <div className="card qitem" key={q.id}>
              <div>
                <div className="ttl">{q.title}</div>
                <div className="sub">
                  Enviado {mine ? 'por ti' : 'por un compañero/a'} ·{' '}
                  {submission!.submittedAt.toLocaleString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </div>
                <div style={{ marginTop: 6 }}><StatusBadge status={status} /></div>
              </div>
              {mine && <Link className="btn ghost sm" href={`/empleado/historial/${submission!.id}`}>Ver</Link>}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
