import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import LogoutButton from '@/components/LogoutButton';

export const dynamic = 'force-dynamic';

export default async function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole('COMERCIAL');
  const store = session.storeIds.length
    ? await db.store.findUnique({ where: { id: session.storeIds[0] } })
    : null;

  return (
    <div className="mshell">
      <div className="mtop">
        <div className="t">
          <strong>avanza fibra</strong>
          <span>{store ? `Tienda ${store.name}` : 'Sin tienda asignada'} · {session.name}</span>
        </div>
        <LogoutButton />
      </div>
      {children}
      <nav className="mnav">
        <Link href="/empleado"><span className="ico">📋</span>Cuestionarios</Link>
        <Link href="/empleado/historial"><span className="ico">🕘</span>Mi historial</Link>
      </nav>
    </div>
  );
}
