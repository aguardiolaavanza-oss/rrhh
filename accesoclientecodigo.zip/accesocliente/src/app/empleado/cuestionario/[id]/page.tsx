import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { Frequency, FREQUENCY_LABELS, periodDeadline } from '@/lib/periods';
import SubmissionForm, { FieldDef } from '@/components/SubmissionForm';

export const dynamic = 'force-dynamic';

export default async function FillPage({ params }: { params: { id: string } }) {
  const session = await requireRole('COMERCIAL');
  const storeId = session.storeIds[0];

  // El cuestionario debe estar activo y asignado a LA TIENDA del comercial
  const q = await db.questionnaire.findFirst({
    where: { id: Number(params.id), active: true, stores: { some: { storeId } } },
    include: { fields: { where: { archived: false }, orderBy: { order: 'asc' } } },
  });
  if (!q) notFound();

  const deadline = periodDeadline(q.frequency as Frequency, q.deadlineTime);
  const fields: FieldDef[] = q.fields.map((f) => ({
    id: f.id,
    label: f.label,
    type: f.type as FieldDef['type'],
    options: f.options ? JSON.parse(f.options) : [],
    required: f.required,
  }));

  return (
    <>
      <p><Link href="/empleado">← Volver</Link></p>
      <h1>{q.title}</h1>
      <p style={{ color: 'var(--ink-2)', marginTop: 0 }}>
        {q.description} {FREQUENCY_LABELS[q.frequency as Frequency]}
        {deadline && <> · Plazo: {deadline.toLocaleString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</>}
      </p>
      <SubmissionForm questionnaireId={q.id} fields={fields} />
    </>
  );
}
