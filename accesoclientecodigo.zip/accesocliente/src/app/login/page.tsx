'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function LoginPage() {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: form.get('email'), password: form.get('password') }),
    });
    const data = await res.json();
    if (res.ok) window.location.href = data.redirect;
    else { setError(data.error || 'Error al iniciar sesión.'); setLoading(false); }
  }

  return (
    <div className="authwrap">
      <div className="authcard">
        <div className="logo">
          <strong>avanza <em>fibra</em></strong>
          <span>TELYRA TELECOM S.L. · Panel interno</span>
        </div>
        {error && <div className="msg err">{error}</div>}
        <form onSubmit={onSubmit}>
          <label className="f"><span>Email</span>
            <input name="email" type="email" required autoComplete="email" placeholder="tu@avanzafibra.com" />
          </label>
          <label className="f"><span>Contraseña</span>
            <input name="password" type="password" required autoComplete="current-password" placeholder="••••••••" />
          </label>
          <button className="btn orange" style={{ width: '100%', justifyContent: 'center' }} disabled={loading}>
            {loading ? 'Entrando…' : 'Iniciar sesión'}
          </button>
        </form>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: 13 }}>
          <Link href="/recuperar">¿Has olvidado tu contraseña?</Link>
        </p>
      </div>
    </div>
  );
}
