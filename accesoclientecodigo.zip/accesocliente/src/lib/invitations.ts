import crypto from 'crypto';
import { db } from './db';
import { sendInvitationEmail, MailResult } from './email';

// Crea un token de invitación, registra la invitación (auditoría: quién la
// envía, cuándo, rol y tiendas en ese momento) y envía el email.
export async function inviteUser(userId: number, sentById: number): Promise<MailResult> {
  const user = await db.user.findUniqueOrThrow({
    where: { id: userId },
    include: { stores: { include: { store: true } } },
  });

  // Invalida tokens de invitación anteriores (reenviar genera enlace nuevo)
  await db.authToken.deleteMany({ where: { userId, type: 'INVITE' } });

  const token = crypto.randomBytes(32).toString('hex');
  await db.authToken.create({
    data: {
      token,
      type: 'INVITE',
      userId,
      expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000),
    },
  });

  await db.invitation.create({
    data: {
      userId,
      sentById,
      roleAtSend: user.role,
      storesAtSend: user.stores.map((s) => s.store.name).join(', ') || '—',
    },
  });

  return sendInvitationEmail(user.email, user.name, token);
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export const VALID_ROLES = ['ADMIN', 'RRHH', 'GESTOR', 'COMERCIAL'] as const;
