import { Prisma } from '@prisma/client';
import { db } from './db';
import { SessionUser, visibleStoreIds } from './auth';

// Filtros combinables del panel de administración. Esta función es la ÚNICA
// fuente de verdad del filtrado: la usan el dashboard, el histórico y la
// exportación a Excel, por lo que lo exportado coincide siempre con lo
// mostrado en pantalla. El alcance por rol (gestor → solo sus tiendas) se
// aplica aquí, en backend, antes que cualquier filtro elegido por el usuario.

export interface AdminFilters {
  tienda?: string; // id de tienda
  buscar?: string; // texto de búsqueda por nombre de tienda (lupa)
  gestor?: string; // id de gestor (solo ADMIN/RRHH)
  cuestionario?: string; // id de cuestionario
  desde?: string; // fecha YYYY-MM-DD
  hasta?: string;
}

export interface ResolvedFilters {
  where: Prisma.SubmissionWhereInput;
  storeIds: number[]; // tiendas resultantes tras alcance + filtros
  allVisibleStores: { id: number; name: string }[];
  from: Date | null;
  to: Date | null;
}

export async function resolveFilters(session: SessionUser, f: AdminFilters): Promise<ResolvedFilters> {
  const visible = await visibleStoreIds(session);
  const allVisibleStores = await db.store.findMany({
    where: { id: { in: visible } },
    orderBy: { name: 'asc' },
    select: { id: true, name: true },
  });

  let storeIds = visible;

  // Filtro por gestor: restringe a las tiendas asignadas a ese gestor
  if (f.gestor && (session.role === 'ADMIN' || session.role === 'RRHH')) {
    const gestor = await db.user.findFirst({
      where: { id: Number(f.gestor), role: 'GESTOR' },
      include: { stores: true },
    });
    if (gestor) {
      const gestorStores = gestor.stores.map((s) => s.storeId);
      storeIds = storeIds.filter((id) => gestorStores.includes(id));
    }
  }

  // Búsqueda por nombre de tienda (input con lupa)
  if (f.buscar?.trim()) {
    const t = f.buscar.trim().toLowerCase();
    const matching = allVisibleStores.filter((s) => s.name.toLowerCase().includes(t)).map((s) => s.id);
    storeIds = storeIds.filter((id) => matching.includes(id));
  }

  // Selector desplegable de tienda
  if (f.tienda) {
    const id = Number(f.tienda);
    storeIds = storeIds.filter((s) => s === id);
  }

  const from = f.desde ? new Date(`${f.desde}T00:00:00`) : null;
  const to = f.hasta ? new Date(`${f.hasta}T23:59:59.999`) : null;

  const where: Prisma.SubmissionWhereInput = {
    storeId: { in: storeIds },
    ...(f.cuestionario ? { questionnaireId: Number(f.cuestionario) } : {}),
    ...(from || to
      ? { submittedAt: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } }
      : {}),
  };

  return { where, storeIds, allVisibleStores, from, to };
}
