import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { db } from './db';

const SECRET = new TextEncoder().encode(process.env.AUTH_SECRET || 'dev-secret');
const COOKIE = 'telyra_session';

export type Role = 'ADMIN' | 'RRHH' | 'GESTOR' | 'COMERCIAL';

export interface SessionUser {
  id: number;
  name: string;
  email: string;
  role: Role;
  storeIds: number[];
}

export async function createSession(userId: number) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(SECRET);
  cookies().set(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export function destroySession() {
  cookies().delete(COOKIE);
}

// Lee la sesión y valida contra la BD en cada petición: una cuenta
// desactivada pierde el acceso inmediatamente aunque su cookie siga viva.
export async function getSession(): Promise<SessionUser | null> {
  const token = cookies().get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, SECRET);
    const uid = Number(payload.uid);
    if (!uid) return null;
    const user = await db.user.findUnique({
      where: { id: uid },
      include: { stores: true },
    });
    if (!user || user.status !== 'ACTIVO') return null;
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role as Role,
      storeIds: user.stores.map((s) => s.storeId),
    };
  } catch {
    return null;
  }
}

// Guard para páginas: redirige a /login si no hay sesión o el rol no está permitido.
export async function requireRole(...roles: Role[]): Promise<SessionUser> {
  const session = await getSession();
  if (!session) redirect('/login');
  if (!roles.includes(session.role)) redirect(homeFor(session.role));
  return session;
}

// Guard para API routes: devuelve la sesión o null (el handler responde 401/403).
export async function apiSession(...roles: Role[]): Promise<SessionUser | null> {
  const session = await getSession();
  if (!session) return null;
  if (roles.length && !roles.includes(session.role)) return null;
  return session;
}

export function homeFor(role: Role): string {
  return role === 'COMERCIAL' ? '/empleado' : '/admin';
}

// Tiendas visibles según rol: ADMIN y RRHH ven todas; GESTOR solo las asignadas;
// COMERCIAL solo la suya. Esta función es la base de TODOS los filtros de datos.
export async function visibleStoreIds(session: SessionUser): Promise<number[]> {
  if (session.role === 'ADMIN' || session.role === 'RRHH') {
    const stores = await db.store.findMany({ select: { id: true } });
    return stores.map((s) => s.id);
  }
  return session.storeIds;
}
