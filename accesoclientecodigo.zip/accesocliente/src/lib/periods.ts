// Lógica de periodos y plazos de los cuestionarios.
// DIARIO  -> un envío por día,   clave "2026-07-03"
// SEMANAL -> un envío por semana ISO, clave "2026-S27" (plazo: domingo)
// MENSUAL -> un envío por mes,   clave "2026-07" (plazo: último día del mes)
// PUNTUAL -> sin recurrencia ni plazo, clave "PUNTUAL" (se puede enviar siempre)

export type Frequency = 'DIARIO' | 'SEMANAL' | 'MENSUAL' | 'PUNTUAL';
export type PeriodStatus = 'A_TIEMPO' | 'POR_VENCER' | 'VENCIDO' | 'COMPLETADO' | 'COMPLETADO_TARDE';

const pad = (n: number) => String(n).padStart(2, '0');

export function dateKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function isoWeek(d: Date): { year: number; week: number } {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  // Jueves de la misma semana ISO determina el año
  date.setDate(date.getDate() + 3 - ((date.getDay() + 6) % 7));
  const year = date.getFullYear();
  const jan4 = new Date(year, 0, 4);
  jan4.setDate(jan4.getDate() + 3 - ((jan4.getDay() + 6) % 7));
  const week = 1 + Math.round((date.getTime() - jan4.getTime()) / (7 * 24 * 3600 * 1000));
  return { year, week };
}

export function periodKey(frequency: Frequency, now: Date = new Date()): string {
  switch (frequency) {
    case 'DIARIO':
      return dateKey(now);
    case 'SEMANAL': {
      const { year, week } = isoWeek(now);
      return `${year}-S${pad(week)}`;
    }
    case 'MENSUAL':
      return `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;
    case 'PUNTUAL':
      return 'PUNTUAL';
  }
}

// Fecha/hora límite del periodo actual (null si no aplica plazo).
export function periodDeadline(
  frequency: Frequency,
  deadlineTime: string | null,
  now: Date = new Date()
): Date | null {
  if (frequency === 'PUNTUAL') return null;
  const [h, m] = (deadlineTime || '23:59').split(':').map(Number);
  if (frequency === 'DIARIO') {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, 59);
  }
  if (frequency === 'SEMANAL') {
    // Domingo de la semana ISO actual
    const day = (now.getDay() + 6) % 7; // lunes=0 ... domingo=6
    const sunday = new Date(now.getFullYear(), now.getMonth(), now.getDate() + (6 - day));
    return new Date(sunday.getFullYear(), sunday.getMonth(), sunday.getDate(), h, m, 59);
  }
  // MENSUAL: último día del mes
  const last = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  return new Date(last.getFullYear(), last.getMonth(), last.getDate(), h, m, 59);
}

const SOON_MS = 2 * 60 * 60 * 1000; // "a punto de vencer" = quedan menos de 2 horas

export function periodStatus(
  frequency: Frequency,
  deadlineTime: string | null,
  submitted: { late: boolean } | null,
  now: Date = new Date()
): PeriodStatus {
  if (submitted) return submitted.late ? 'COMPLETADO_TARDE' : 'COMPLETADO';
  const deadline = periodDeadline(frequency, deadlineTime, now);
  if (!deadline) return 'A_TIEMPO';
  if (now.getTime() > deadline.getTime()) return 'VENCIDO';
  if (deadline.getTime() - now.getTime() < SOON_MS) return 'POR_VENCER';
  return 'A_TIEMPO';
}

// ¿Un envío realizado en `at` llegó tarde respecto al plazo de su periodo?
export function isLate(frequency: Frequency, deadlineTime: string | null, at: Date): boolean {
  const deadline = periodDeadline(frequency, deadlineTime, at);
  return deadline !== null && at.getTime() > deadline.getTime();
}

export const FREQUENCY_LABELS: Record<Frequency, string> = {
  DIARIO: 'Diario',
  SEMANAL: 'Semanal',
  MENSUAL: 'Mensual',
  PUNTUAL: 'Puntual',
};

export const STATUS_LABELS: Record<PeriodStatus, string> = {
  A_TIEMPO: 'A tiempo',
  POR_VENCER: 'A punto de vencer',
  VENCIDO: 'Vencido',
  COMPLETADO: 'Completado',
  COMPLETADO_TARDE: 'Completado (tarde)',
};
