import nodemailer from 'nodemailer';

// Envío de emails de invitación/recuperación. Si no hay SMTP configurado
// (SMTP_HOST vacío), funcionamos en "modo desarrollo": el enlace se
// devuelve al llamador para mostrarlo en el panel y se registra en consola.

export interface MailResult {
  sent: boolean; // true = email enviado por SMTP; false = modo desarrollo
  link: string;
}

function smtpConfigured(): boolean {
  return Boolean(process.env.SMTP_HOST);
}

async function send(to: string, subject: string, html: string): Promise<boolean> {
  if (!smtpConfigured()) return false;
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined,
  });
  await transport.sendMail({ from: process.env.SMTP_FROM || 'no-reply@avanzafibra.com', to, subject, html });
  return true;
}

const wrapper = (title: string, body: string, cta: string, link: string) => `
  <div style="font-family:Urbanist,Arial,sans-serif;max-width:520px;margin:0 auto;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
    <div style="background:#17304F;padding:20px 28px"><span style="color:#fff;font-size:18px;font-weight:700">Avanza Fibra</span>
      <span style="color:#9fb3cc;font-size:12px;display:block">TELYRA TELECOM S.L. · Panel interno</span></div>
    <div style="padding:28px">
      <h2 style="color:#17304F;margin:0 0 12px">${title}</h2>
      <p style="color:#334155;line-height:1.6">${body}</p>
      <p style="text-align:center;margin:28px 0">
        <a href="${link}" style="background:#E57A28;color:#fff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:600">${cta}</a>
      </p>
      <p style="color:#94a3b8;font-size:12px">Si el botón no funciona, copia este enlace: ${link}</p>
    </div>
  </div>`;

export async function sendInvitationEmail(to: string, name: string, token: string): Promise<MailResult> {
  const link = `${process.env.APP_URL || 'http://localhost:3000'}/invitacion/${token}`;
  const sent = await send(
    to,
    'Invitación al panel interno de Avanza Fibra',
    wrapper(
      `Hola, ${name}`,
      'Se te ha dado de alta en el panel interno de Avanza Fibra. Haz clic en el botón para crear tu contraseña y activar tu cuenta. El enlace caduca en 7 días.',
      'Crear mi contraseña',
      link
    )
  );
  if (!sent) console.log(`[email dev] Invitación para ${to}: ${link}`);
  return { sent, link };
}

export async function sendResetEmail(to: string, name: string, token: string): Promise<MailResult> {
  const link = `${process.env.APP_URL || 'http://localhost:3000'}/restablecer/${token}`;
  const sent = await send(
    to,
    'Recuperación de contraseña — Avanza Fibra',
    wrapper(
      `Hola, ${name}`,
      'Hemos recibido una solicitud para restablecer tu contraseña. Si no has sido tú, ignora este mensaje. El enlace caduca en 2 horas.',
      'Restablecer contraseña',
      link
    )
  );
  if (!sent) console.log(`[email dev] Reset para ${to}: ${link}`);
  return { sent, link };
}
