import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const db = new PrismaClient();

// Datos de arranque: tiendas Murcia y Alicante, un usuario por rol,
// cuestionarios de ejemplo (incluido el conteo de caja que alimenta el
// ranking de recaudación) y ~2 semanas de envíos históricos de muestra.

async function main() {
  const hash = await bcrypt.hash('Avanza1234', 10);

  const murcia = await db.store.upsert({ where: { name: 'Murcia' }, update: {}, create: { name: 'Murcia' } });
  const alicante = await db.store.upsert({ where: { name: 'Alicante' }, update: {}, create: { name: 'Alicante' } });

  const mkUser = (name: string, email: string, role: string, storeIds: number[]) =>
    db.user.upsert({
      where: { email },
      update: {},
      create: {
        name,
        email,
        role,
        status: 'ACTIVO',
        passwordHash: hash,
        stores: { create: storeIds.map((storeId) => ({ storeId })) },
      },
    });

  const admin = await mkUser('Administradora Principal', 'admin@avanzafibra.com', 'ADMIN', []);
  await mkUser('Rocío RRHH', 'rrhh@avanzafibra.com', 'RRHH', []);
  const gestor = await mkUser('Gabriel Gestor', 'gestor@avanzafibra.com', 'GESTOR', [murcia.id, alicante.id]);
  const comMurcia = await mkUser('Carmen Comercial (Murcia)', 'comercial.murcia@avanzafibra.com', 'COMERCIAL', [murcia.id]);
  const comAlicante = await mkUser('Alberto Comercial (Alicante)', 'comercial.alicante@avanzafibra.com', 'COMERCIAL', [alicante.id]);

  if (await db.questionnaire.count()) {
    console.log('Seed: ya hay cuestionarios, no se duplican.');
    return;
  }

  // 1) Conteo de caja diario — el campo "Importe recaudado (€)" tiene
  // isCashAmount=true y alimenta el ranking de recaudación por gestor.
  const caja = await db.questionnaire.create({
    data: {
      title: 'Conteo de caja diario',
      description: 'Arqueo de caja al cierre de tienda.',
      frequency: 'DIARIO',
      deadlineTime: '21:30',
      createdById: admin.id,
      stores: { create: [{ storeId: murcia.id }, { storeId: alicante.id }] },
      fields: {
        create: [
          { label: 'Importe recaudado (€)', type: 'NUMERO', required: true, isCashAmount: true, order: 0 },
          { label: 'Nº de operaciones', type: 'NUMERO', required: true, order: 1 },
          { label: 'Caja cuadrada', type: 'CHECKBOX', order: 2 },
          { label: 'Incidencias del día', type: 'TEXTO', order: 3 },
          { label: 'Foto del arqueo', type: 'FOTO', order: 4 },
        ],
      },
    },
    include: { fields: true },
  });

  // 2) Limpieza semanal
  await db.questionnaire.create({
    data: {
      title: 'Control de limpieza y estado de tienda',
      description: 'Revisión semanal del estado general de la tienda.',
      frequency: 'SEMANAL',
      deadlineTime: '20:00',
      createdById: admin.id,
      stores: { create: [{ storeId: murcia.id }, { storeId: alicante.id }] },
      fields: {
        create: [
          { label: 'Escaparate limpio', type: 'CHECKBOX', order: 0 },
          { label: 'Zona de atención ordenada', type: 'CHECKBOX', order: 1 },
          { label: 'Estado general', type: 'SELECCION', options: JSON.stringify(['Excelente', 'Bueno', 'Mejorable', 'Deficiente']), required: true, order: 2 },
          { label: 'Fecha de la última limpieza a fondo', type: 'FECHA', order: 3 },
          { label: 'Observaciones', type: 'TEXTO', order: 4 },
          { label: 'Foto del estado de la tienda', type: 'FOTO', order: 5 },
        ],
      },
    },
  });

  // 3) Incidencias (puntual, sin plazo)
  await db.questionnaire.create({
    data: {
      title: 'Registro de incidencias',
      description: 'Comunicación puntual de incidencias en tienda.',
      frequency: 'PUNTUAL',
      createdById: admin.id,
      stores: { create: [{ storeId: murcia.id }, { storeId: alicante.id }] },
      fields: {
        create: [
          { label: 'Tipo de incidencia', type: 'SELECCION', options: JSON.stringify(['Avería', 'Robo/hurto', 'Cliente', 'Sistemas', 'Otra']), required: true, order: 0 },
          { label: 'Fecha de la incidencia', type: 'FECHA', required: true, order: 1 },
          { label: 'Descripción', type: 'TEXTO', required: true, order: 2 },
          { label: 'Requiere seguimiento', type: 'CHECKBOX', order: 3 },
          { label: 'Foto (opcional)', type: 'FOTO', order: 4 },
        ],
      },
    },
  });

  // Histórico de muestra: conteos de caja de los últimos 14 días (sin hoy,
  // para poder probar el flujo de envío). Murcia recauda más que Alicante
  // para que el ranking tenga un líder claro.
  const cashField = caja.fields.find((f) => f.isCashAmount)!;
  const opsField = caja.fields.find((f) => f.label === 'Nº de operaciones')!;
  const okField = caja.fields.find((f) => f.label === 'Caja cuadrada')!;

  const pad = (n: number) => String(n).padStart(2, '0');
  for (let i = 14; i >= 1; i--) {
    const day = new Date();
    day.setDate(day.getDate() - i);
    const key = `${day.getFullYear()}-${pad(day.getMonth() + 1)}-${pad(day.getDate())}`;
    for (const [store, user, base] of [
      [murcia, comMurcia, 950] as const,
      [alicante, comAlicante, 610] as const,
    ]) {
      // Envío a las 21:05 (en plazo) salvo un par de días tarde en Alicante
      const late = store.id === alicante.id && (i === 3 || i === 7);
      const at = new Date(day.getFullYear(), day.getMonth(), day.getDate(), late ? 22 : 21, late ? 40 : 5);
      const amount = base + ((i * 37) % 260) - 60;
      await db.submission.create({
        data: {
          questionnaireId: caja.id,
          storeId: store.id,
          userId: user.id,
          periodKey: key,
          submittedAt: at,
          late,
          answers: {
            create: [
              { fieldId: cashField.id, labelSnapshot: cashField.label, value: String(amount) },
              { fieldId: opsField.id, labelSnapshot: opsField.label, value: String(8 + (i % 9)) },
              { fieldId: okField.id, labelSnapshot: okField.label, value: 'true' },
            ],
          },
        },
      });
    }
  }

  console.log('Seed completado.');
  console.log('Cuentas (contraseña: Avanza1234):');
  console.log('  admin@avanzafibra.com (ADMIN) · rrhh@avanzafibra.com (RRHH)');
  console.log('  gestor@avanzafibra.com (GESTOR: Murcia + Alicante)');
  console.log('  comercial.murcia@avanzafibra.com · comercial.alicante@avanzafibra.com');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
