# Panel interno TELYRA TELECOM S.L. (Avanza Fibra)

Aplicación web tipo CRM/dashboard que sustituye los cuestionarios en papel de las tiendas
(control de caja, limpieza, incidencias…) por formularios digitales con panel de resultados,
ranking de recaudación por gestor y gestión de accesos con invitaciones por email.

## Stack

| Capa | Tecnología | Por qué |
|---|---|---|
| Frontend + Backend | **Next.js 14 (App Router) + TypeScript** | Una sola app: páginas renderizadas en servidor (los permisos se aplican en backend en cada petición) y API routes para las mutaciones. |
| Base de datos | **SQLite + Prisma** | Cero infraestructura para arrancar; el esquema tipado migra a PostgreSQL cambiando una línea (`datasource`). |
| Excel | **exceljs** | Importación masiva con validación fila a fila y exportación .xlsx con estilos. |
| Emails | **nodemailer** | Invitaciones y recuperación de contraseña vía SMTP configurable. Sin SMTP, "modo desarrollo": el enlace se muestra en el panel para copiarlo. |
| Sesiones | **jose (JWT en cookie httpOnly) + bcryptjs** | Sesión firmada de 7 días que se revalida contra la BD en cada petición (revocar acceso surte efecto inmediato). |
| Estilos | CSS propio con tokens de marca | Identidad corporativa: `#17304F`, `#356EB5`, `#E57A28` (resalte), `#000000`, `#5A5A5A`, `#F4F4F4`; tipografía **Urbanist** (@fontsource). |
| Mapa | **es-atlas + topojson-client + d3-geo** | Mapa de España por provincias (64 KB, sin servicios externos) con zoom por rueda/botones/arrastre, buscador de tiendas e inset de Canarias. |

## Puesta en marcha

```bash
npm install
npm run setup     # crea la BD SQLite y carga los datos de ejemplo
npm run build && npm start   # o: npm run dev
```

Abrir http://localhost:3000. Cuentas de ejemplo (contraseña **Avanza1234**):

| Email | Rol | Ámbito |
|---|---|---|
| admin@avanzafibra.com | Admin | Todo + gestión de accesos |
| rrhh@avanzafibra.com | RRHH | Panel admin, todas las tiendas |
| gestor@avanzafibra.com | Gestor | Panel admin, Murcia + Alicante |
| comercial.murcia@avanzafibra.com | Comercial | Solo rellena cuestionarios de Murcia |
| comercial.alicante@avanzafibra.com | Comercial | Solo rellena cuestionarios de Alicante |

Variables en `.env`: `DATABASE_URL`, `AUTH_SECRET` (cambiar en producción), `APP_URL` y `SMTP_*`
(si `SMTP_HOST` queda vacío, los enlaces de invitación/reset se muestran en el panel y en la consola).

## Estructura del proyecto

```
prisma/schema.prisma        Modelo de datos · prisma/seed.ts  Datos de ejemplo
src/lib/
  auth.ts                   Sesión JWT, guards por rol, visibleStoreIds() (base de TODO el filtrado)
  periods.ts                Periodos (diario/semanal/mensual/puntual), plazos y semáforo
  adminFilters.ts           Filtros combinables: única fuente de verdad para dashboard, histórico y export
  invitations.ts / email.ts Invitaciones con auditoría + envío de emails
src/app/
  login, recuperar, restablecer/[token], invitacion/[token]    Autenticación
  empleado/…                Panel móvil del comercial (pendientes, rellenar, historial propio)
  admin/…                   Dashboard, ranking, cuestionarios (form builder), histórico, usuarios
  api/…                     Endpoints REST (auth, submissions, files protegidos, admin/*)
src/components/…            FiltersBar, BarChart, QuestionnaireBuilder, UserForm, ImportUsers…
uploads/                    Fotos adjuntas (servidas SOLO vía /api/files con control de permisos)
```

## Modelo de datos

- **Store** — tienda (entidad propia; añadir tiendas no toca código).
- **User** — rol `ADMIN | RRHH | GESTOR | COMERCIAL`, estado `INVITADO | ACTIVO | DESACTIVADO`.
- **UserStore** — asignación usuario↔tienda (Gestor: varias; Comercial: una).
- **Invitation** — auditoría de cada invitación: quién la envió, cuándo, rol y tiendas en ese momento, aceptación.
- **AuthToken** — tokens de un solo uso (INVITE 7 días, RESET 2 h).
- **Questionnaire** — título, frecuencia, hora límite, activo; desactivar nunca borra respuestas.
- **Field** — tipos `TEXTO | NUMERO | SELECCION | FECHA | CHECKBOX | FOTO`; `isCashAmount` marca el
  importe que alimenta el ranking; `archived` retira un campo sin borrar su histórico.
- **QuestionnaireStore** — a qué tiendas aplica cada cuestionario.
- **Submission** — envío: fecha/hora, tienda, usuario, periodo (`2026-07-03`, `2026-S27`, `2026-07`), `late`.
- **Answer** — respuesta por campo con `labelSnapshot` (el histórico sobrevive a cualquier edición) y `filePath` para fotos.

## Cómo probar cada requisito

1. **Login por rol**: entrar con cada cuenta de la tabla. Comercial aterriza en `/empleado` (móvil), el resto en `/admin`. Un comercial que teclee `/admin` es redirigido; sus llamadas a APIs de admin devuelven 403.
2. **Crear/editar cuestionario**: como RRHH → Cuestionarios → "+ Nuevo cuestionario" (título, campos de todos los tipos, tiendas, frecuencia, hora límite). Editar "Conteo de caja diario" y quitar un campo con respuestas: se "retira" (archiva) y los envíos antiguos siguen mostrando su etiqueta original. Desactivar el cuestionario no borra nada del histórico.
3. **Ranking con varias tiendas**: como gestor@ (Murcia+Alicante) → "Ranking recaudación": tiendas ordenadas por importe del campo 💶 de los conteos de caja, con la primera destacada en naranja como "Prioridad de recogida". Admin/RRHH ven el ranking de todos los gestores; cada gestor solo el suyo.
4. **Importación masiva**: como admin → Gestión de accesos → "Importación masiva" → descargar plantilla → subir el Excel. Cada fila se valida por separado (email inválido, rol inexistente, tienda desconocida, duplicados…) y el resumen indica fila a fila qué se importó y qué falló y por qué.
5. **Filtro/búsqueda por tienda**: en Dashboard o Histórico, teclear en la lupa ("ali…") o usar el desplegable; combinable con gestor, cuestionario y rango de fechas. La URL refleja los filtros.
   - **Mapa de España**: en el dashboard, cada tienda aparece sobre su provincia con su recaudación (naranja = la de mayor importe). Zoom con la rueda, los botones ＋/− o arrastrando; el buscador del mapa acerca la vista a la tienda elegida y el clic en un marcador filtra todo el dashboard por esa tienda. Las tiendas nuevas se sitúan automáticamente si su nombre coincide con su provincia.
6. **Marcado de vencido**: crear un cuestionario diario con hora límite ya pasada (p. ej. 00:01): el comercial lo ve en rojo "Vencido" y el semáforo del dashboard también; si lo envía, queda marcado "Completado (tarde)" / "Fuera de plazo".
7. **Exportación a Excel**: botón "⬇ Exportar a Excel" en Dashboard/Histórico: genera un .xlsx con exactamente las filas filtradas (misma función de filtrado en pantalla y export). Filtrando por un cuestionario concreto, cada campo va en su propia columna. Sin filtros exporta el histórico completo del ámbito del usuario.
8. **Invitaciones**: al crear un usuario se registra la invitación (quién/cuándo/rol/tiendas) y se envía el email (o se muestra el enlace si no hay SMTP). El enlace pide crear contraseña (mín. 8), activa la cuenta y entra directamente. "Reenviar invitación" genera enlace nuevo e invalida el anterior. Revocar acceso expulsa al usuario al instante aunque tenga sesión abierta.

## Añadir una tienda nueva

Sin tocar código: `INSERT` en la tabla `Store` (o `npx prisma studio` → Store → Add record). Aparece
automáticamente en formularios de usuario, form builder, filtros e importación masiva.
